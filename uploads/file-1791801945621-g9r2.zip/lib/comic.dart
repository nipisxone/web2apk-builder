import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:http/http.dart' as http;
import 'package:url_launcher/url_launcher.dart';

class ComicPage extends StatefulWidget {
  const ComicPage({super.key});

  @override
  State<ComicPage> createState() => _ComicPageState();
}

class _ComicPageState extends State<ComicPage> {
  // === TEMA NEON (SESUAI DENGAN APLIKASI) ===
  static const Color bgPrimary = Color(0xFF0A0E1A);
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color accentPurple = Color(0xFF9C27B0);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF94A3B8);
  
  Color get glassPrimary => const Color(0x1AFFFFFF);
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);

  LinearGradient get neonGradient => const LinearGradient(
        colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  // Controller pencarian
  final TextEditingController _searchController = TextEditingController();
  
  // Data List
  List<dynamic> _comicList = [];
  bool _isLoading = true;
  bool _isSearching = false;
  String _headingText = "Hot Comic";

  @override
  void initState() {
    super.initState();
    _fetchTopManga();
  }

  // === API FUNCTIONS (Jikan API V4) ===
  Future<void> _fetchTopManga() async {
    setState(() { _isLoading = true; _isSearching = false; _headingText = "Hot Comic"; });
    try {
      final response = await http.get(Uri.parse('https://api.jikan.moe/v4/top/manga?limit=20'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _comicList = data['data'];
          _isLoading = false;
        });
      }
    } catch (e) {
      debugPrint("Error fetching manga: $e");
      setState(() => _isLoading = false);
    }
  }

  Future<void> _searchManga(String query) async {
    if (query.isEmpty) return;
    setState(() { _isLoading = true; _isSearching = true; _headingText = "Search Result"; });
    try {
      final response = await http.get(Uri.parse('https://api.jikan.moe/v4/manga?q=$query&limit=20'));
      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        setState(() {
          _comicList = data['data'];
          _isLoading = false;
        });
      }
    } catch (e) {
      debugPrint("Error searching manga: $e");
      setState(() => _isLoading = false);
    }
  }

  // === LAUNCH URL DENGAN VALIDASI ===
  Future<void> _launchUrl(String url) async {
    if (url.isEmpty) {
      _showSnackBar('URL tidak tersedia untuk manga ini');
      return;
    }

    // Pastikan ada protocol
    String validUrl = url;
    if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
      validUrl = 'https://$validUrl';
    }

    try {
      final uri = Uri.parse(validUrl);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        _showSnackBar('Tidak bisa membuka link');
      }
    } catch (e) {
      _showSnackBar('Error: $e');
    }
  }

  void _showSnackBar(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgPrimary,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [glassPrimary, glassSecondary],
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: glassBorder),
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: accentNeon, size: 18),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: const Text("✦ Comic Zone", style: TextStyle(fontFamily: "Orbitron", fontWeight: FontWeight.bold, fontSize: 16, color: Colors.white)),
        flexibleSpace: ClipRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
            child: Container(color: Colors.black.withOpacity(0.5)),
          ),
        ),
      ),
      body: Stack(
        children: [
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topCenter,
                end: Alignment.bottomCenter,
                colors: [Color(0xFF0A0E1A), Color(0xFF000000)],
              ),
            ),
          ),
          
          SingleChildScrollView(
            physics: const BouncingScrollPhysics(),
            padding: const EdgeInsets.symmetric(horizontal: 16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 100),

                // HEADER CARD
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(20),
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [glassPrimary, glassSecondary],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(20),
                    border: Border.all(color: glassBorder),
                    boxShadow: [
                      BoxShadow(color: accentNeon.withOpacity(0.1), blurRadius: 15, offset: const Offset(0, 4))
                    ]
                  ),
                  child: Column(
                    children: [
                      Icon(FontAwesomeIcons.bookOpenReader, color: accentNeon, size: 35),
                      const SizedBox(height: 10),
                      Text("Comic Zone", style: TextStyle(color: accentNeon, fontSize: 22, fontFamily: "Orbitron", fontWeight: FontWeight.bold, shadows: [BoxShadow(color: accentNeon, blurRadius: 10)])),
                      const SizedBox(height: 5),
                      const Text("Read & Find Your Favorite Manga", style: TextStyle(color: softGrey, fontFamily: "ShareTechMono", fontSize: 12)),
                    ],
                  ),
                ),

                const SizedBox(height: 25),

                // SEARCH BAR
                Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [glassPrimary, glassSecondary],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
                    borderRadius: BorderRadius.circular(15),
                    border: Border.all(color: glassBorder),
                  ),
                  child: TextField(
                    controller: _searchController,
                    style: const TextStyle(color: primaryWhite, fontFamily: "ShareTechMono"),
                    decoration: InputDecoration(
                      hintText: "Search Manga / Comic...",
                      hintStyle: const TextStyle(color: softGrey),
                      prefixIcon: Icon(Icons.search, color: accentNeon),
                      border: InputBorder.none,
                      contentPadding: const EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                      suffixIcon: IconButton(
                        icon: Icon(Icons.send, color: accentNeon, size: 20),
                        onPressed: () => _searchManga(_searchController.text),
                      ),
                    ),
                    onSubmitted: (value) => _searchManga(value),
                  ),
                ),

                const SizedBox(height: 15),

                // RECOMMENDATION CHIPS
                const Text("Recommendation Search:", style: TextStyle(color: softGrey, fontSize: 10, fontFamily: "Orbitron")),
                const SizedBox(height: 8),
                SingleChildScrollView(
                  scrollDirection: Axis.horizontal,
                  physics: const BouncingScrollPhysics(),
                  child: Row(
                    children: [
                      _buildRecChip("One Piece"),
                      _buildRecChip("Naruto"),
                      _buildRecChip("Solo Leveling"),
                      _buildRecChip("Berserk"),
                      _buildRecChip("Chainsaw Man"),
                    ],
                  ),
                ),

                const SizedBox(height: 30),

                // TITLE SECTION
                Row(
                  children: [
                    Container(
                      height: 20, width: 4,
                      decoration: BoxDecoration(gradient: neonGradient, borderRadius: BorderRadius.circular(2)),
                    ),
                    const SizedBox(width: 10),
                    Text(_headingText, style: const TextStyle(color: primaryWhite, fontSize: 18, fontFamily: "Orbitron", fontWeight: FontWeight.bold)),
                    const Spacer(),
                    if(_isSearching)
                      GestureDetector(
                        onTap: _fetchTopManga,
                        child: const Text("Reset", style: TextStyle(color: accentNeon, fontSize: 12)),
                      )
                  ],
                ),

                const SizedBox(height: 15),

                // GRID LIST COMIC
                _isLoading 
                  ? Container(height: 300, alignment: Alignment.center, child: CircularProgressIndicator(color: accentNeon))
                  : GridView.builder(
                      shrinkWrap: true,
                      physics: const NeverScrollableScrollPhysics(),
                      gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                        crossAxisCount: 2,
                        childAspectRatio: 0.65,
                        crossAxisSpacing: 12,
                        mainAxisSpacing: 12,
                      ),
                      itemCount: _comicList.length,
                      itemBuilder: (context, index) {
                        final manga = _comicList[index];
                        return _buildComicCard(manga);
                      },
                    ),

                const SizedBox(height: 50),
              ],
            ),
          ),
        ],
      ),
    );
  }

  // --- HELPER WIDGETS ---

  Widget _buildRecChip(String text) {
    return Padding(
      padding: const EdgeInsets.only(right: 8.0),
      child: InkWell(
        onTap: () {
          _searchController.text = text;
          _searchManga(text);
        },
        borderRadius: BorderRadius.circular(20),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [glassPrimary, glassSecondary],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: glassBorder),
          ),
          child: Text(text, style: const TextStyle(color: primaryWhite, fontSize: 11, fontFamily: "ShareTechMono")),
        ),
      ),
    );
  }

  Widget _buildComicCard(dynamic manga) {
    String imageUrl = manga['images']['jpg']['image_url'] ?? '';
    String title = manga['title'] ?? 'Unknown';
    String score = manga['score'] != null ? manga['score'].toString() : 'N/A';
    String type = manga['type'] ?? 'Manga';

    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (_) => ComicDetailPage(mangaData: manga)));
      },
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(12),
          gradient: LinearGradient(
            colors: [glassPrimary, glassSecondary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          border: Border.all(color: glassBorder),
          boxShadow: [BoxShadow(color: accentNeon.withOpacity(0.05), blurRadius: 5)]
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              child: ClipRRect(
                borderRadius: const BorderRadius.vertical(top: Radius.circular(12)),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.network(
                      imageUrl, 
                      fit: BoxFit.cover,
                      errorBuilder: (context, error, stackTrace) => Container(
                        color: bgPrimary,
                        child: const Icon(Icons.broken_image, color: softGrey),
                      ),
                    ),
                    Positioned(
                      top: 5, right: 5,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          gradient: neonGradient,
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Row(
                          children: [
                            const Icon(Icons.star, color: Colors.amber, size: 10),
                            const SizedBox(width: 3),
                            Text(score, style: const TextStyle(color: primaryWhite, fontSize: 10, fontWeight: FontWeight.bold)),
                          ],
                        ),
                      ),
                    ),
                    Positioned(
                      top: 5, left: 5,
                      child: Container(
                        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                        decoration: BoxDecoration(
                          color: accentNeon.withOpacity(0.8),
                          borderRadius: BorderRadius.circular(4),
                        ),
                        child: Text(type, style: const TextStyle(color: primaryWhite, fontSize: 9, fontWeight: FontWeight.bold)),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: primaryWhite, fontSize: 12, fontWeight: FontWeight.bold, fontFamily: "Orbitron")),
                  const SizedBox(height: 5),
                  Text("Tap to read story", style: TextStyle(color: softGrey, fontSize: 9, fontStyle: FontStyle.italic)),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// --- HALAMAN DETAIL KOMIK (DIPERBAIKI) ===
class ComicDetailPage extends StatelessWidget {
  final Map<String, dynamic> mangaData;

  const ComicDetailPage({super.key, required this.mangaData});

  // === TEMA NEON (TAMBAHKAN DI DALAM CLASS) ===
  static const Color bgPrimary = Color(0xFF0A0E1A);
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color accentPurple = Color(0xFF9C27B0);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF94A3B8);

  Color get glassPrimary => const Color(0x1AFFFFFF);
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);

  LinearGradient get neonGradient => const LinearGradient(
        colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  // === FUNGSI LAUNCH URL DENGAN VALIDASI ===
  Future<void> _launchUrl(BuildContext context, String url) async {
    if (url.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('URL tidak tersedia untuk manga ini'),
          backgroundColor: Colors.orange,
          behavior: SnackBarBehavior.floating,
        ),
      );
      return;
    }

    // Pastikan ada protocol
    String validUrl = url;
    if (!validUrl.startsWith('http://') && !validUrl.startsWith('https://')) {
      validUrl = 'https://$validUrl';
    }

    try {
      final uri = Uri.parse(validUrl);
      if (await canLaunchUrl(uri)) {
        await launchUrl(uri, mode: LaunchMode.externalApplication);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Tidak bisa membuka link'),
            backgroundColor: Colors.red,
            behavior: SnackBarBehavior.floating,
          ),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error: $e'),
          backgroundColor: Colors.red,
          behavior: SnackBarBehavior.floating,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    String imageUrl = mangaData['images']['jpg']['large_image_url'] ?? mangaData['images']['jpg']['image_url'] ?? '';
    String title = mangaData['title'] ?? 'Unknown';
    String synopsis = mangaData['synopsis'] ?? 'No synopsis available.';
    String status = mangaData['status'] ?? 'Unknown';
    String chapters = mangaData['chapters'] != null ? mangaData['chapters'].toString() : '?';
    String url = mangaData['url'] ?? '';

    return Scaffold(
      backgroundColor: bgPrimary,
      body: CustomScrollView(
        physics: const BouncingScrollPhysics(),
        slivers: [
          SliverAppBar(
            expandedHeight: 400.0,
            floating: false,
            pinned: true,
            backgroundColor: bgPrimary,
            flexibleSpace: FlexibleSpaceBar(
              background: Stack(
                fit: StackFit.expand,
                children: [
                  imageUrl.isNotEmpty
                      ? Image.network(imageUrl, fit: BoxFit.cover)
                      : Container(color: bgPrimary),
                  Container(
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        begin: Alignment.topCenter, end: Alignment.bottomCenter,
                        colors: [Colors.transparent, bgPrimary.withOpacity(0.9), bgPrimary],
                        stops: const [0.5, 0.8, 1.0]
                      ),
                    ),
                  ),
                ],
              ),
            ),
            leading: IconButton(
              icon: Container(
                padding: const EdgeInsets.all(5),
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    colors: [glassPrimary, glassSecondary],
                  ),
                  shape: BoxShape.circle,
                ),
                child: const Icon(Icons.arrow_back, color: Colors.white),
              ),
              onPressed: () => Navigator.pop(context),
            ),
          ),
          
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.all(20.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title, style: const TextStyle(fontFamily: "Orbitron", fontSize: 24, fontWeight: FontWeight.bold, color: primaryWhite)),
                  const SizedBox(height: 10),
                  
                  Row(
                    children: [
                      _buildInfoBadge(Icons.timelapse, status, accentNeon),
                      const SizedBox(width: 10),
                      _buildInfoBadge(Icons.book, "$chapters Ch", accentPurple),
                      const SizedBox(width: 10),
                      _buildInfoBadge(Icons.star, "${mangaData['score'] ?? 'N/A'}", Colors.amber),
                    ],
                  ),
                  const SizedBox(height: 25),

                  const Divider(color: accentNeon, thickness: 1),
                  const SizedBox(height: 15),

                  const Row(
                    children: [
                      Icon(Icons.description, color: accentNeon, size: 18),
                      SizedBox(width: 8),
                      Text("Story / Synopsis", style: TextStyle(color: primaryWhite, fontSize: 16, fontFamily: "Orbitron", fontWeight: FontWeight.bold)),
                    ],
                  ),
                  const SizedBox(height: 10),
                  
                  Text(
                    synopsis,
                    style: const TextStyle(color: softGrey, fontSize: 13, height: 1.6, fontFamily: "ShareTechMono"),
                    textAlign: TextAlign.justify,
                  ),

                  const SizedBox(height: 40),

                  SizedBox(
                    width: double.infinity,
                    height: 50,
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: accentNeon,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
                        elevation: 10,
                        shadowColor: accentNeon.withOpacity(0.5)
                      ),
                      onPressed: () => _launchUrl(context, url),
                      icon: const Icon(Icons.open_in_browser, color: Colors.white),
                      label: const Text(
                        "Read More & Details on Web",
                        style: TextStyle(color: Colors.white, fontFamily: "Orbitron", fontWeight: FontWeight.bold),
                      ),
                    ),
                  ),
                  const SizedBox(height: 50),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildInfoBadge(IconData icon, String text, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: color.withOpacity(0.15),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(color: color.withOpacity(0.3))
      ),
      child: Row(
        children: [
          Icon(icon, color: color, size: 14),
          const SizedBox(width: 5),
          Text(text, style: TextStyle(color: color, fontSize: 11, fontWeight: FontWeight.bold)),
        ],
      ),
    );
  }
}