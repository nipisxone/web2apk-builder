import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:video_player/video_player.dart';
import 'login_page.dart';

void main() {
  runApp(const MaterialApp(
    home: LandingPage(),
    debugShowCheckedModeBanner: false,
  ));
}

class LandingPage extends StatefulWidget {
  const LandingPage({super.key});

  @override
  State<LandingPage> createState() => _LandingPageState();
}

class _LandingPageState extends State<LandingPage> {
  late VideoPlayerController _videoController;

  // === TEMA NEON FUTURISTIK ===
  static const Color bgPrimary = Color(0xFF0A0E1A);
  static const Color bgSecondary = Color(0xFF111828);
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color accentPurple = Color(0xFF9C27B0);
  static const Color accentPink = Color(0xFFEC4899);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF94A3B8);
  static const Color cardBg = Color(0xFF1A1F3A);

  Color get glassPrimary => const Color(0x1AFFFFFF);
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);

  LinearGradient get neonGradient => const LinearGradient(
        colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  LinearGradient get purpleGradient => const LinearGradient(
        colors: [Color(0xFF9C27B0), Color(0xFFEC4899)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  @override
  void initState() {
    super.initState();
    _videoController = VideoPlayerController.asset('assets/videos/landing.mp4')
      ..initialize().then((_) {
        setState(() {});
        _videoController.setLooping(true);
        _videoController.setVolume(1.0);
        _videoController.play();
      });
  }

  @override
  void dispose() {
    _videoController.dispose();
    super.dispose();
  }

  Future<void> _launchSocialUrl(String urlString) async {
    final Uri url = Uri.parse(urlString);
    try {
      if (!await launchUrl(url, mode: LaunchMode.externalApplication)) {
        debugPrint("Could not launch $urlString");
      }
    } catch (e) {
      debugPrint("Error launching URL: $e");
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgPrimary,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topLeft,
            radius: 1.5,
            colors: [
              accentNeon.withOpacity(0.05),
              bgPrimary,
              bgPrimary,
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
        ),
        child: CustomPaint(
          painter: _NeonGridPainter(),
          child: SafeArea(
            child: SingleChildScrollView(
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _buildNeonLogoSection(),
                  _buildNeonHeaderTitle(),
                  const SizedBox(height: 40),
                  _buildNeonFeatureCard(),
                  const SizedBox(height: 35),
                  _buildNeonActionButtons(context),
                  const SizedBox(height: 25),
                  _buildNeonSocialSection(),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  // ==================== NEON LOGO SECTION ====================
  Widget _buildNeonLogoSection() {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 600),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.scale(scale: value, child: child),
        );
      },
      child: Container(
        width: double.infinity,
        margin: const EdgeInsets.only(bottom: 10),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: accentNeon.withOpacity(0.3),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: accentNeon.withOpacity(0.1),
              blurRadius: 20,
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: AspectRatio(
            aspectRatio: 16 / 9,
            child: _videoController.value.isInitialized
                ? VideoPlayer(_videoController)
                : Container(
                    color: bgSecondary,
                    child: const Center(
                      child: CircularProgressIndicator(
                        color: accentNeon,
                        strokeWidth: 3,
                      ),
                    ),
                  ),
          ),
        ),
      ),
    );
  }

  // ==================== NEON HEADER TITLE ====================
  Widget _buildNeonHeaderTitle() {
    return Column(
      children: [
        ShaderMask(
          blendMode: BlendMode.srcIn,
          shaderCallback: (bounds) => neonGradient.createShader(
            Rect.fromLTWH(0, 0, bounds.width, bounds.height),
          ),
          child: const Text(
            "Viciousx",
            style: TextStyle(
              fontFamily: 'Orbitron',
              fontSize: 38,
              fontWeight: FontWeight.w900,
              letterSpacing: 2,
            ),
          ),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [
                accentNeon.withOpacity(0.1),
                accentPurple.withOpacity(0.1),
              ],
            ),
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
              color: accentNeon.withOpacity(0.2),
            ),
          ),
          child: Text(
            "✦ GACOR • TERUPDATE • STABIL ✦",
            style: TextStyle(
              color: accentNeon,
              fontSize: 10,
              letterSpacing: 4,
              fontWeight: FontWeight.w600,
            ),
          ),
        ),
      ],
    );
  }

  // ==================== NEON FEATURE CARD ====================
  Widget _buildNeonFeatureCard() {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 700),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 30 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 30, horizontal: 20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [glassPrimary, glassSecondary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: glassBorder),
          boxShadow: [
            BoxShadow(
              color: accentNeon.withOpacity(0.05),
              blurRadius: 30,
              offset: const Offset(0, 10),
            ),
          ],
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                gradient: neonGradient,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: accentNeon.withOpacity(0.3),
                    blurRadius: 20,
                  ),
                ],
              ),
              child: const Icon(
                Icons.shield_outlined,
                color: primaryWhite,
                size: 30,
              ),
            ),
            const SizedBox(height: 20),
            ShaderMask(
              shaderCallback: (bounds) => neonGradient.createShader(bounds),
              child: const Text(
                "Viciousx BUG",
                style: TextStyle(
                  color: primaryWhite,
                  fontSize: 18,
                  letterSpacing: 1.5,
                  fontWeight: FontWeight.bold,
                  fontFamily: 'Orbitron',
                ),
              ),
            ),
            const SizedBox(height: 12),
            Text(
              "Aplikasi dengan desain elegan dan fitur terbaru.\nPengembangan langsung oleh @danzz0122.",
              textAlign: TextAlign.center,
              style: TextStyle(
                color: softGrey,
                fontSize: 12,
                height: 1.6,
              ),
            ),
            const SizedBox(height: 16),
            Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    accentNeon.withOpacity(0.2),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  Icons.verified_rounded,
                  color: accentNeon,
                  size: 14,
                ),
                const SizedBox(width: 6),
                Text(
                  "Secure & Reliable",
                  style: TextStyle(
                    color: softGrey,
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // ==================== NEON ACTION BUTTONS ====================
  Widget _buildNeonActionButtons(BuildContext context) {
    return Column(
      children: [
        _buildNeonButton(
          title: "LOGIN TO SYSTEM",
          icon: FontAwesomeIcons.rocket,
          isPrimary: true,
          onTap: () => Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const LoginPage()),
          ),
        ),
        const SizedBox(height: 16),
        _buildNeonButton(
          title: "CONTACT SUPPORT",
          icon: Icons.support_agent,
          isPrimary: false,
          onTap: () => _launchSocialUrl("https://t.me/@danzz0122"),
        ),
      ],
    );
  }

  Widget _buildNeonButton({
    required String title,
    required IconData icon,
    required bool isPrimary,
    required VoidCallback onTap,
  }) {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 600),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(15),
          child: Container(
            width: double.infinity,
            height: 55,
            decoration: BoxDecoration(
              gradient: isPrimary
                  ? neonGradient
                  : LinearGradient(
                      colors: [glassPrimary, glassSecondary],
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                    ),
              borderRadius: BorderRadius.circular(15),
              border: Border.all(
                color: isPrimary ? accentNeon : glassBorder,
                width: 1.2,
              ),
              boxShadow: isPrimary
                  ? [
                      BoxShadow(
                        color: accentNeon.withOpacity(0.3),
                        blurRadius: 15,
                      ),
                      BoxShadow(
                        color: accentPurple.withOpacity(0.2),
                        blurRadius: 30,
                      ),
                    ]
                  : [],
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(
                  icon,
                  color: isPrimary ? primaryWhite : accentNeon,
                  size: 16,
                ),
                const SizedBox(width: 12),
                Text(
                  title,
                  style: TextStyle(
                    fontFamily: 'Orbitron',
                    fontWeight: FontWeight.bold,
                    fontSize: 14,
                    color: isPrimary ? primaryWhite : accentNeon,
                    letterSpacing: 1.5,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ==================== NEON SOCIAL SECTION ====================
  Widget _buildNeonSocialSection() {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 800),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 30 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 24, horizontal: 20),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [glassPrimary, glassSecondary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(28),
          border: Border.all(color: glassBorder),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    accentNeon.withOpacity(0.1),
                    accentPurple.withOpacity(0.1),
                  ],
                ),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: accentNeon.withOpacity(0.2),
                ),
              ),
              child: Text(
                "✦ HUBUNGI KAMI ✦",
                style: TextStyle(
                  fontFamily: 'Orbitron',
                  color: accentNeon,
                  fontSize: 10,
                  letterSpacing: 3,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),
            const SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildNeonSocialIcon(
                  FontAwesomeIcons.telegram,
                  "Telegram",
                  "https://t.me/@danzz0122",
                  const Color(0xFF0088cc),
                ),
                _buildNeonSocialIcon(
                  FontAwesomeIcons.telegram,
                  "Channel",
                  "https://t.me/@danzz0122",
                  const Color(0xFF0088cc),
                ),
                _buildNeonSocialIcon(
                  FontAwesomeIcons.tiktok,
                  "TikTok",
                  "https://tiktok.com/@danzz0122",
                  accentNeon,
                ),
              ],
            ),
            const SizedBox(height: 12),
            Container(
              height: 1,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Colors.transparent,
                    accentNeon.withOpacity(0.1),
                    Colors.transparent,
                  ],
                ),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              "Terhubunglah dengan kami di media sosial.",
              style: TextStyle(
                color: softGrey,
                fontSize: 9,
                letterSpacing: 1,
                fontWeight: FontWeight.w300,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildNeonSocialIcon(IconData icon, String label, String url, Color color) {
    return InkWell(
      onTap: () => _launchSocialUrl(url),
      borderRadius: BorderRadius.circular(15),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 8),
        child: Column(
          children: [
            Container(
              width: 45,
              height: 45,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                gradient: LinearGradient(
                  colors: [
                    color.withOpacity(0.2),
                    color.withOpacity(0.05),
                  ],
                ),
                border: Border.all(
                  color: color.withOpacity(0.3),
                  width: 1.5,
                ),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.1),
                    blurRadius: 10,
                  ),
                ],
              ),
              child: Icon(
                icon,
                color: color,
                size: 18,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'Orbitron',
                color: softGrey,
                fontSize: 9,
                fontWeight: FontWeight.w500,
                letterSpacing: 0.5,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ===================== NEON GRID PAINTER =====================
class _NeonGridPainter extends CustomPainter {
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color accentPurple = Color(0xFF9C27B0);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.02)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    const gridSize = 30.0;

    // Base grid lines
    for (double x = 0; x <= size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    for (double y = 0; y <= size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    // Neon accent grid
    final neonPaint = Paint()
      ..color = accentNeon.withOpacity(0.05)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final purplePaint = Paint()
      ..color = accentPurple.withOpacity(0.03)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    for (double x = 0; x <= size.width; x += gridSize * 5) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), neonPaint);
    }

    for (double y = 0; y <= size.height; y += gridSize * 5) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), purplePaint);
    }

    // Glowing dots
    final dotPaint = Paint()
      ..color = accentNeon.withOpacity(0.08)
      ..style = PaintingStyle.fill;

    for (double x = 0; x <= size.width; x += gridSize) {
      for (double y = 0; y <= size.height; y += gridSize) {
        canvas.drawCircle(Offset(x, y), 1.5, dotPaint);
      }
    }

    // Diagonal lines
    final diagPaint = Paint()
      ..color = accentNeon.withOpacity(0.015)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;

    for (double i = -size.height; i < size.width + size.height; i += 60) {
      canvas.drawLine(
        Offset(i, 0),
        Offset(i + size.height, size.height),
        diagPaint,
      );
    }

    // Accent circles
    final circlePaint = Paint()
      ..color = accentNeon.withOpacity(0.03)
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1;

    for (double x = 0; x <= size.width; x += gridSize * 10) {
      for (double y = 0; y <= size.height; y += gridSize * 10) {
        canvas.drawCircle(Offset(x, y), gridSize * 2, circlePaint);
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}