// dashboard_page.dart
import 'dart:ui';
import 'dart:convert';
import 'dart:io';
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'package:device_info_plus/device_info_plus.dart';
import 'package:web_socket_channel/web_socket_channel.dart';
import 'package:web_socket_channel/status.dart' as status;
import 'package:font_awesome_flutter/font_awesome_flutter.dart';
import 'package:url_launcher/url_launcher.dart';

import '.dart';
import 'nik_check.dart';
import 'admin_page.dart';
import 'owner_page.dart';
import 'home_page.dart';
import 'seller_page.dart';
import 'change_password_page.dart';
import 'tools_gateway.dart';
import 'login_page.dart';
import 'bug_sender.dart';
import 'contact_page.dart';
import 'profile_page.dart';
import 'riwayat_page.dart';
import 'info_page.dart';
import 'ucapan_page.dart';
import 'toko_page.dart';
import 'public_chat_page.dart';
import 'weather_page.dart';
import 'jadwal_sholat_page.dart';
import 'anime.dart';
import 'game_page.dart';

class DashboardPage extends StatefulWidget {
  final String username;
  final String password;
  final String role;
  final String expiredDate;
  final String sessionKey;
  final List<Map<String, dynamic>> listBug;
  final List<Map<String, dynamic>> listDoos;
  final List<dynamic> news;

  const DashboardPage({
    super.key,
    required this.username,
    required this.password,
    required this.role,
    required this.expiredDate,
    required this.listBug,
    required this.listDoos,
    required this.sessionKey,
    required this.news,
  });

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin {
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;
  late WebSocketChannel? _channel;

  late String sessionKey;
  late String username;
  late String password;
  late String role;
  late String expiredDate;
  late List<Map<String, dynamic>> listBug;
  late List<Map<String, dynamic>> listDoos;
  late List<dynamic> newsList;

  String androidId = "unknown";
  File? _profileImage;

  int _bottomNavIndex = 0;
  Widget _selectedPage = const SizedBox();

  int onlineUsers = 0;
  int activeConnections = 0;

  Timer? _statsTimer;
  Timer? _onlineTimer;

  // === DATA LATEST ANIME ===
  final List<Map<String, dynamic>> _latestAnime = [
    {
      'title': 'Jujutsu Kaisen',
      'episode': 'Season 2',
      'image': 'https://cdn.myanimelist.net/images/anime/1171/109222l.jpg',
      'rating': '8.9',
      'type': 'TV Series',
      'status': 'Ongoing',
    },
    {
      'title': 'One Piece',
      'episode': 'Episode 1080+',
      'image': 'https://cdn.myanimelist.net/images/anime/6/73245l.jpg',
      'rating': '9.0',
      'type': 'TV Series',
      'status': 'Ongoing',
    },
    {
      'title': 'Naruto Shippuden',
      'episode': 'Complete',
      'image': 'https://cdn.myanimelist.net/images/anime/5/87048l.jpg',
      'rating': '8.7',
      'type': 'TV Series',
      'status': 'Completed',
    },
    {
      'title': 'Bleach TYBW',
      'episode': 'Part 2',
      'image': 'https://cdn.myanimelist.net/images/anime/3/40451l.jpg',
      'rating': '8.6',
      'type': 'TV Series',
      'status': 'Ongoing',
    },
    {
      'title': 'Chainsaw Man',
      'episode': 'Season 1',
      'image': 'https://cdn.myanimelist.net/images/anime/1806/126216l.jpg',
      'rating': '8.7',
      'type': 'TV Series',
      'status': 'Completed',
    },
    {
      'title': 'Fullmetal Alchemist',
      'episode': 'Complete',
      'image': 'https://cdn.myanimelist.net/images/anime/5/50307l.jpg',
      'rating': '9.2',
      'type': 'TV Series',
      'status': 'Completed',
    },
    {
      'title': 'Death Note',
      'episode': 'Complete',
      'image': 'https://cdn.myanimelist.net/images/anime/9/9453l.jpg',
      'rating': '8.6',
      'type': 'TV Series',
      'status': 'Completed',
    },
    {
      'title': 'My Hero Academia',
      'episode': 'Season 6',
      'image': 'https://cdn.myanimelist.net/images/anime/1286/99889l.jpg',
      'rating': '8.4',
      'type': 'TV Series',
      'status': 'Ongoing',
    },
  ];

  // === DATA MENU TOOLS (NO EMOJI) ===
  final List<Map<String, dynamic>> _menuTools = [
    {
      'icon': FontAwesomeIcons.telegram,
      'label': 'Info',
      'color': const Color(0xFF0088cc),
      'gradient': const LinearGradient(
        colors: [Color(0xFF0088cc), Color(0xFF00B4FF)],
      ),
      'desc': 'Latest Updates',
    },
    {
      'icon': Icons.wifi_tethering_rounded,
      'label': 'Bug',
      'color': const Color(0xFFE53935),
      'gradient': const LinearGradient(
        colors: [Color(0xFFE53935), Color(0xFFFF6B6B)],
      ),
      'desc': 'Report Issue',
    },
    {
      'icon': Icons.card_giftcard_rounded,
      'label': 'Ucapan',
      'color': const Color(0xFFFFB74D),
      'gradient': const LinearGradient(
        colors: [Color(0xFFFFB74D), Color(0xFFFF8A65)],
      ),
      'desc': 'Send Greeting',
    },
    {
      'icon': Icons.shopping_bag_rounded,
      'label': 'Toko',
      'color': const Color(0xFF00695C),
      'gradient': const LinearGradient(
        colors: [Color(0xFF00695C), Color(0xFF00A86B)],
      ),
      'desc': 'Buy Stuff',
    },
    {
      'icon': Icons.public_rounded,
      'label': 'Chat',
      'color': const Color(0xFFE91E63),
      'gradient': const LinearGradient(
        colors: [Color(0xFFE91E63), Color(0xFFFF6B9D)],
      ),
      'desc': 'Public Chat',
    },
    {
      'icon': Icons.history_rounded,
      'label': 'Riwayat',
      'color': const Color(0xFF9C27B0),
      'gradient': const LinearGradient(
        colors: [Color(0xFF9C27B0), Color(0xFFCE93D8)],
      ),
      'desc': 'Your History',
    },
    {
      'icon': Icons.wb_sunny_rounded,
      'label': 'Cuaca',
      'color': const Color(0xFFFF9800),
      'gradient': const LinearGradient(
        colors: [Color(0xFFFF9800), Color(0xFFFFC107)],
      ),
      'desc': 'Weather Info',
    },
    {
      'icon': Icons.mosque_rounded,
      'label': 'Sholat',
      'color': const Color(0xFF4CAF50),
      'gradient': const LinearGradient(
        colors: [Color(0xFF4CAF50), Color(0xFF66BB6A)],
      ),
      'desc': 'Prayer Time',
    },
  ];

  // === TEMA ===
  static const Color bgPrimary = Color(0xFF080C1A);
  static const Color bgSecondary = Color(0xFF0F1426);
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color accentPurple = Color(0xFF9C27B0);
  static const Color accentPink = Color(0xFFEC4899);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF8A99B0);

  Color get glassPrimary => const Color(0x1AFFFFFF);
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);

  LinearGradient get neonGradient => const LinearGradient(
        colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  LinearGradient get purpleGradient => const LinearGradient(
        colors: [Color(0xFF9C27B0), Color(0xFFEC4899)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  @override
  void initState() {
    super.initState();
    sessionKey = widget.sessionKey;
    username = widget.username;
    password = widget.password;
    role = widget.role;
    expiredDate = widget.expiredDate;
    listBug = widget.listBug;
    listDoos = widget.listDoos;
    newsList = widget.news;

    _initAnimations();
    _selectedPage = _buildHomePage();

    _initAndroidIdAndConnect();
    _loadProfileImage();
    _startStatsTimer();

    _fetchOnlineUsers();
    _startOnlinePolling();
  }

  void _startStatsTimer() {
    _statsTimer = Timer.periodic(const Duration(seconds: 5), (timer) {
      if (_channel != null) {
        _channel?.sink.add(jsonEncode({"type": "stats"}));
      }
    });
  }

  Future<void> _fetchOnlineUsers() async {
    try {
      final response = await http.get(
        Uri.parse('$apiBaseUrl/getOnlineUsers?key=$sessionKey'),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        if (data['valid'] == true) {
          setState(() {
            onlineUsers = data['count'] ?? 0;
          });
        }
      }
    } catch (e) {
      print('Error fetching online users: $e');
    }
  }

  void _startOnlinePolling() {
    _onlineTimer = Timer.periodic(const Duration(seconds: 10), (timer) {
      _fetchOnlineUsers();
    });
  }

  void _initAnimations() {
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    )..forward();

    _fadeAnimation = CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeOut,
    );

    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(
      CurvedAnimation(
        parent: _animationController,
        curve: Curves.easeOutCubic,
      ),
    );
  }

  Future<void> _loadProfileImage() async {
    final prefs = await SharedPreferences.getInstance();
    final imagePath = prefs.getString('profile_image_$username');
    if (imagePath != null && imagePath.isNotEmpty) {
      setState(() {
        _profileImage = File(imagePath);
      });
    }
  }

  Future<void> _initAndroidIdAndConnect() async {
    final deviceInfo = await DeviceInfoPlugin().androidInfo;
    androidId = deviceInfo.id;
    _connectToWebSocket();
  }

  void _connectToWebSocket() {
    _channel = WebSocketChannel.connect(Uri.parse('$apiBaseUrl'));
    _channel?.sink.add(jsonEncode({
      "type": "validate",
      "key": sessionKey,
      "androidId": androidId,
    }));
    _channel?.sink.add(jsonEncode({"type": "stats"}));

    _channel?.stream.listen((event) {
      final data = jsonDecode(event);
      if (data['type'] == 'myInfo') {
        if (data['valid'] == false) {
          if (data['reason'] == 'androidIdMismatch') {
            _handleInvalidSession("Your account has logged on another device.");
          } else if (data['reason'] == 'keyInvalid') {
            _handleInvalidSession("Key is not valid. Please login again.");
          }
        }
      }
      if (data['type'] == 'stats') {
        if (!mounted) return;
        setState(() {
          onlineUsers = data['onlineUsers'] ?? 0;
          activeConnections = data['activeConnections'] ?? 0;
        });
      }
    });
  }

  Future<void> _openUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception("Could not launch $uri");
    }
  }

  void _handleInvalidSession(String message) async {
    await Future.delayed(const Duration(milliseconds: 300));
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (!mounted) return;
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) => AlertDialog(
        backgroundColor: bgSecondary,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(28),
          side: BorderSide(color: accentNeon.withOpacity(0.3), width: 1.5),
        ),
        title: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(8),
              decoration: BoxDecoration(
                gradient: neonGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: const Icon(
                Icons.warning_amber_rounded,
                color: Colors.white,
                size: 24,
              ),
            ),
            const SizedBox(width: 12),
            const Text(
              "Session Expired",
              style: TextStyle(
                color: accentNeon,
                fontWeight: FontWeight.w700,
                fontSize: 18,
              ),
            ),
          ],
        ),
        content: Text(
          message,
          style: const TextStyle(color: softGrey, fontSize: 14),
        ),
        actions: [
          Container(
            decoration: BoxDecoration(
              gradient: neonGradient,
              borderRadius: BorderRadius.circular(16),
            ),
            child: TextButton(
              onPressed: () {
                Navigator.of(context).pushAndRemoveUntil(
                  MaterialPageRoute(builder: (_) => const LoginPage()),
                  (route) => false,
                );
              },
              child: const Text(
                "OK",
                style: TextStyle(
                  color: primaryWhite,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  void _onBottomNavTapped(int index) {
    setState(() {
      _bottomNavIndex = index;
      if (index == 0) {
        _selectedPage = _buildHomePage();
      } else if (index == 1) {
        _selectedPage = HomePage(
          username: username,
          password: password,
          listBug: listBug,
          role: role,
          expiredDate: expiredDate,
          sessionKey: sessionKey,
        );
      } else if (index == 2) {
        _selectedPage = InfoPage(sessionKey: sessionKey);
      } else if (index == 3) {
        _selectedPage = ToolsPage(
          sessionKey: sessionKey,
          userRole: role,
          listDoos: listDoos,
        );
      }
    });
  }

  void _onSidebarTabSelected(int index) {
    Navigator.pop(context);
    Future.delayed(const Duration(milliseconds: 200), () {
      setState(() {
        if (index == 1) {
          _selectedPage = SellerPage(keyToken: sessionKey);
        } else if (index == 2) {
          _selectedPage = AdminPage(sessionKey: sessionKey);
        } else if (index == 3) {
          _selectedPage = OwnerPage(sessionKey: sessionKey, username: username);
        }
      });
    });
  }

  // ============================================================
  // HOME PAGE - PREMIUM
  // ============================================================
  Widget _buildHomePage() {
    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _buildPremiumHeader(),
          const SizedBox(height: 20),
          _buildStatsRow(),
          const SizedBox(height: 24),
          if (newsList.isNotEmpty) ...[
            _buildSectionHeader('🔥 LATEST NEWS', '${newsList.length} Articles'),
            const SizedBox(height: 12),
            _buildNewsList(),
          ],
          const SizedBox(height: 24),
          _buildSectionHeader('🎬 LATEST ANIME', 'View All'),
          const SizedBox(height: 12),
          _buildAnimeList(),
          const SizedBox(height: 24),
          _buildSectionHeader('🛠 MENU TOOLS', ''),
          const SizedBox(height: 12),
          _buildToolsGrid(),
          const SizedBox(height: 24),
          _buildSectionHeader('🎮 GAME ZONE', '6 Games'),
          const SizedBox(height: 12),
          _buildGameList(),
          const SizedBox(height: 32),
        ],
      ),
    );
  }

  // ============================================================
  // HEADER PREMIUM
  // ============================================================
  Widget _buildPremiumHeader() {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            accentNeon.withOpacity(0.08),
            accentPurple.withOpacity(0.05),
            Colors.transparent,
          ],
        ),
        borderRadius: BorderRadius.circular(28),
        border: Border.all(
          color: accentNeon.withOpacity(0.12),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: accentNeon.withOpacity(0.04),
            blurRadius: 40,
            spreadRadius: 5,
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  gradient: neonGradient,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: accentNeon.withOpacity(0.2),
                      blurRadius: 10,
                    ),
                  ],
                ),
                child: const Text(
                  "✦ Viciousx",
                  style: TextStyle(
                    color: primaryWhite,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                    letterSpacing: 1.5,
                  ),
                ),
              ),
              const Spacer(),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  color: const Color(0xFF22C55E).withOpacity(0.12),
                  borderRadius: BorderRadius.circular(20),
                  border: Border.all(
                    color: const Color(0xFF22C55E).withOpacity(0.2),
                  ),
                ),
                child: Row(
                  children: [
                    AnimatedContainer(
                      duration: const Duration(milliseconds: 800),
                      width: 8,
                      height: 8,
                      decoration: BoxDecoration(
                        color: const Color(0xFF22C55E),
                        shape: BoxShape.circle,
                        boxShadow: [
                          BoxShadow(
                            color: const Color(0xFF22C55E).withOpacity(0.6),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                    ),
                    const SizedBox(width: 6),
                    const Text(
                      "LIVE",
                      style: TextStyle(
                        color: Color(0xFF22C55E),
                        fontSize: 10,
                        fontWeight: FontWeight.bold,
                        letterSpacing: 1,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          const Text(
            "Welcome Back,",
            style: TextStyle(
              color: softGrey,
              fontSize: 13,
              fontWeight: FontWeight.w500,
              letterSpacing: 0.5,
            ),
          ),
          const SizedBox(height: 2),
          Row(
            children: [
              Text(
                username,
                style: const TextStyle(
                  fontSize: 28,
                  fontWeight: FontWeight.bold,
                  color: primaryWhite,
                  letterSpacing: -0.5,
                ),
              ),
              const SizedBox(width: 10),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 5),
                decoration: BoxDecoration(
                  gradient: neonGradient,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: accentNeon.withOpacity(0.2),
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: Text(
                  role.toUpperCase(),
                  style: const TextStyle(
                    color: primaryWhite,
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 1.2,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  // ============================================================
  // STATS ROW
  // ============================================================
  Widget _buildStatsRow() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: Row(
        children: [
          _buildStatsCard('👥', 'Online Users', "$onlineUsers", accentNeon),
          const SizedBox(width: 12),
          _buildStatsCard('🔗', 'Active', "$activeConnections", accentPurple),
          const SizedBox(width: 12),
          _buildStatsCard('📅', 'Expiration', expiredDate, const Color(0xFFF59E0B)),
        ],
      ),
    );
  }

  Widget _buildStatsCard(String emoji, String label, String value, Color color) {
    return Expanded(
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [glassPrimary, glassSecondary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: color.withOpacity(0.12),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.05),
              blurRadius: 15,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(emoji, style: const TextStyle(fontSize: 16)),
                const SizedBox(width: 6),
                Text(
                  label,
                  style: TextStyle(
                    color: softGrey,
                    fontSize: 10,
                    fontWeight: FontWeight.w500,
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              value,
              style: TextStyle(
                color: primaryWhite,
                fontSize: 20,
                fontWeight: FontWeight.bold,
                letterSpacing: -0.5,
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // SECTION HEADER
  // ============================================================
  Widget _buildSectionHeader(String title, String subtitle) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20),
      child: Row(
        children: [
          Container(
            width: 4,
            height: 22,
            decoration: BoxDecoration(
              gradient: neonGradient,
              borderRadius: BorderRadius.circular(4),
            ),
          ),
          const SizedBox(width: 10),
          ShaderMask(
            shaderCallback: (bounds) => neonGradient.createShader(bounds),
            child: Text(
              title,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 14,
                fontWeight: FontWeight.w700,
                letterSpacing: 1.5,
              ),
            ),
          ),
          const Spacer(),
          if (subtitle.isNotEmpty)
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
              decoration: BoxDecoration(
                color: accentNeon.withOpacity(0.08),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: accentNeon.withOpacity(0.15),
                ),
              ),
              child: Text(
                subtitle,
                style: TextStyle(
                  color: accentNeon,
                  fontSize: 10,
                  fontWeight: FontWeight.w600,
                  letterSpacing: 0.5,
                ),
              ),
            ),
        ],
      ),
    );
  }

  // ============================================================
  // NEWS LIST
  // ============================================================
  Widget _buildNewsList() {
    return SizedBox(
      height: 290,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: newsList.length,
        itemBuilder: (context, index) {
          final item = newsList[index];
          return _buildNewsCard(item, index);
        },
      ),
    );
  }

  Widget _buildNewsCard(dynamic item, int index) {
    if (item == null) return const SizedBox();

    return Container(
      width: MediaQuery.of(context).size.width * 0.82,
      margin: const EdgeInsets.only(right: 14),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        gradient: LinearGradient(
          colors: [glassPrimary, glassSecondary],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        border: Border.all(
          color: accentNeon.withOpacity(0.08),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: accentNeon.withOpacity(0.04),
            blurRadius: 30,
            offset: const Offset(0, 8),
          ),
        ],
      ),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(
              flex: 2,
              child: Stack(
                children: [
                  Positioned.fill(
                    child: item['image'] != null && item['image'].toString().isNotEmpty
                        ? Image.network(
                            item['image'],
                            fit: BoxFit.cover,
                            errorBuilder: (_, __, ___) => Container(
                              color: bgSecondary.withOpacity(0.5),
                              child: const Center(
                                child: Icon(Icons.broken_image, color: softGrey, size: 40),
                              ),
                            ),
                            loadingBuilder: (context, child, loadingProgress) {
                              if (loadingProgress == null) return child;
                              return Container(
                                color: bgSecondary.withOpacity(0.3),
                                child: const Center(
                                  child: CircularProgressIndicator(
                                    color: accentNeon,
                                    strokeWidth: 2,
                                  ),
                                ),
                              );
                            },
                          )
                        : Container(
                            color: bgSecondary.withOpacity(0.5),
                            child: const Center(
                              child: Icon(Icons.image_outlined, color: softGrey, size: 40),
                            ),
                          ),
                  ),
                  Positioned.fill(
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.black.withOpacity(0.2),
                            Colors.transparent,
                            Colors.black.withOpacity(0.5),
                          ],
                          begin: Alignment.topCenter,
                          end: Alignment.bottomCenter,
                          stops: const [0.0, 0.4, 1.0],
                        ),
                      ),
                    ),
                  ),
                  Positioned(
                    top: 12,
                    left: 12,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                      decoration: BoxDecoration(
                        gradient: neonGradient,
                        borderRadius: BorderRadius.circular(10),
                        boxShadow: [
                          BoxShadow(
                            color: accentNeon.withOpacity(0.2),
                            blurRadius: 10,
                          ),
                        ],
                      ),
                      child: Text(
                        "NEWS ${index + 1}",
                        style: const TextStyle(
                          color: primaryWhite,
                          fontSize: 9,
                          fontWeight: FontWeight.bold,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              flex: 1,
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      item['title'] ?? 'No Title',
                      style: const TextStyle(
                        color: primaryWhite,
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.3,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 4),
                    Text(
                      item['desc'] ?? '',
                      style: TextStyle(
                        color: primaryWhite.withOpacity(0.5),
                        fontSize: 11,
                        height: 1.3,
                      ),
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Icon(Icons.access_time_rounded, color: accentNeon, size: 12),
                        const SizedBox(width: 4),
                        Text(
                          _formatDate(item['created_at']),
                          style: TextStyle(color: softGrey, fontSize: 10),
                        ),
                        const Spacer(),
                        Container(
                          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                          decoration: BoxDecoration(
                            gradient: neonGradient,
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: const Text(
                            "Read",
                            style: TextStyle(
                              color: primaryWhite,
                              fontSize: 9,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  String _formatDate(String? dateString) {
    if (dateString == null) return "Baru saja";
    try {
      final date = DateTime.parse(dateString);
      final now = DateTime.now();
      final diff = now.difference(date);

      if (diff.inDays > 0) {
        return "${diff.inDays} hari lalu";
      } else if (diff.inHours > 0) {
        return "${diff.inHours} jam lalu";
      } else if (diff.inMinutes > 0) {
        return "${diff.inMinutes} menit lalu";
      } else {
        return "Baru saja";
      }
    } catch (e) {
      return dateString;
    }
  }

  // ============================================================
  // ANIME LIST
  // ============================================================
  Widget _buildAnimeList() {
    return SizedBox(
      height: 230,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: _latestAnime.length,
        itemBuilder: (context, index) {
          final anime = _latestAnime[index];
          return _buildAnimeCard(anime);
        },
      ),
    );
  }

  Widget _buildAnimeCard(Map<String, dynamic> anime) {
    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const HomeAnimePage(),
          ),
        );
      },
      child: Container(
        width: 150,
        margin: const EdgeInsets.only(right: 14),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(
            color: accentNeon.withOpacity(0.08),
            width: 1,
          ),
          boxShadow: [
            BoxShadow(
              color: accentNeon.withOpacity(0.03),
              blurRadius: 20,
              offset: const Offset(0, 4),
            ),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.circular(20),
          child: Stack(
            children: [
              Positioned.fill(
                child: Image.network(
                  anime['image'] ?? '',
                  fit: BoxFit.cover,
                  errorBuilder: (context, error, stackTrace) {
                    return Container(
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [accentNeon.withOpacity(0.15), accentPurple.withOpacity(0.15)],
                        ),
                      ),
                      child: const Center(
                        child: Icon(Icons.movie, color: Colors.white38, size: 40),
                      ),
                    );
                  },
                  loadingBuilder: (context, child, loadingProgress) {
                    if (loadingProgress == null) return child;
                    return Container(
                      color: bgSecondary,
                      child: const Center(
                        child: SizedBox(
                          width: 24,
                          height: 24,
                          child: CircularProgressIndicator(
                            color: accentNeon,
                            strokeWidth: 2,
                          ),
                        ),
                      ),
                    );
                  },
                ),
              ),
              Positioned.fill(
                child: Container(
                  decoration: BoxDecoration(
                    gradient: LinearGradient(
                      colors: [
                        Colors.transparent,
                        Colors.black.withOpacity(0.6),
                      ],
                      begin: Alignment.topCenter,
                      end: Alignment.bottomCenter,
                    ),
                  ),
                ),
              ),
              Positioned(
                top: 10,
                right: 10,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    gradient: const LinearGradient(
                      colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
                    ),
                    borderRadius: BorderRadius.circular(8),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.amber.withOpacity(0.2),
                        blurRadius: 8,
                      ),
                    ],
                  ),
                  child: Row(
                    children: [
                      const Icon(Icons.star, color: Colors.black, size: 10),
                      const SizedBox(width: 3),
                      Text(
                        anime['rating'] ?? '8.0',
                        style: const TextStyle(
                          color: Colors.black,
                          fontSize: 10,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                top: 10,
                left: 10,
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: (anime['status'] == 'Ongoing' ? Colors.green : Colors.blue).withOpacity(0.85),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    anime['status'] ?? 'Ongoing',
                    style: const TextStyle(
                      color: primaryWhite,
                      fontSize: 8,
                      fontWeight: FontWeight.w600,
                      letterSpacing: 0.5,
                    ),
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Padding(
                  padding: const EdgeInsets.all(10),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        anime['title']!,
                        style: const TextStyle(
                          color: primaryWhite,
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 0.3,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      const SizedBox(height: 4),
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: accentNeon.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(
                                color: accentNeon.withOpacity(0.15),
                              ),
                            ),
                            child: Text(
                              anime['episode']!,
                              style: TextStyle(
                                color: accentNeon,
                                fontSize: 9,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                          const SizedBox(width: 6),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                            decoration: BoxDecoration(
                              color: accentPurple.withOpacity(0.15),
                              borderRadius: BorderRadius.circular(6),
                              border: Border.all(
                                color: accentPurple.withOpacity(0.15),
                              ),
                            ),
                            child: Text(
                              anime['type'] ?? 'TV',
                              style: TextStyle(
                                color: accentPurple,
                                fontSize: 9,
                                fontWeight: FontWeight.w600,
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              Positioned(
                bottom: 0,
                left: 0,
                right: 0,
                child: Container(
                  height: 2,
                  decoration: BoxDecoration(
                    gradient: neonGradient,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  // ============================================================
  // TOOLS GRID (NO EMOJI)
  // ============================================================
  Widget _buildToolsGrid() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 16),
      child: GridView.builder(
        shrinkWrap: true,
        physics: const NeverScrollableScrollPhysics(),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 4,
          crossAxisSpacing: 12,
          mainAxisSpacing: 12,
          childAspectRatio: 0.9,
        ),
        itemCount: _menuTools.length,
        itemBuilder: (context, index) {
          final menu = _menuTools[index];
          return _buildToolItem(menu, index);
        },
      ),
    );
  }

  Widget _buildToolItem(Map<String, dynamic> menu, int index) {
    final Color color = menu['color'] as Color;
    final IconData icon = menu['icon'] as IconData;
    final String label = menu['label'] as String;
    final String desc = menu['desc'] as String;
    final LinearGradient gradient = menu['gradient'] as LinearGradient;

    VoidCallback onTap;
    switch (index) {
      case 0:
        onTap = () => _openUrl("https://t.me/sylraformasi");
        break;
      case 1:
        onTap = () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => BugSenderPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          );
        };
        break;
      case 2:
        onTap = () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => UcapanPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          );
        };
        break;
      case 3:
        onTap = () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => const TokoPage(),
            ),
          );
        };
        break;
      case 4:
        onTap = () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => PublicChatPage(
                sessionKey: sessionKey,
                username: username,
                role: role,
              ),
            ),
          );
        };
        break;
      case 5:
        onTap = () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => RiwayatPage(
                sessionKey: sessionKey,
                role: role,
              ),
            ),
          );
        };
        break;
      case 6:
        onTap = () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => WeatherPage(
                sessionKey: sessionKey,
                username: username,
              ),
            ),
          );
        };
        break;
      case 7:
        onTap = () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => JadwalSholatPage(
                sessionKey: sessionKey,
                username: username,
              ),
            ),
          );
        };
        break;
      default:
        onTap = () {};
    }

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 8),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [glassPrimary, glassSecondary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(
            color: color.withOpacity(0.1),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.05),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(11),
              decoration: BoxDecoration(
                gradient: gradient,
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.2),
                    blurRadius: 8,
                  ),
                ],
              ),
              child: Icon(icon, color: primaryWhite, size: 20),
            ),
            const SizedBox(height: 6),
            Text(
              label,
              style: const TextStyle(
                color: primaryWhite,
                fontSize: 10,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.2,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Text(
              desc,
              style: TextStyle(
                color: softGrey,
                fontSize: 7.5,
                fontWeight: FontWeight.w400,
                letterSpacing: 0.1,
              ),
              textAlign: TextAlign.center,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
            Container(
              margin: const EdgeInsets.only(top: 4),
              width: 20,
              height: 2,
              decoration: BoxDecoration(
                gradient: gradient,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // GAME LIST (UKURAN PAS - 100x135)
  // ============================================================
  Widget _buildGameList() {
    final List<Map<String, dynamic>> games = [
      {'icon': Icons.numbers, 'label': 'Tebak Angka', 'color': accentNeon, 'emoji': '🔢'},
      {'icon': Icons.grid_on, 'label': 'Tic Tac Toe', 'color': accentPurple, 'emoji': '❌'},
      {'icon': Icons.casino, 'label': 'Dadu', 'color': accentPink, 'emoji': '🎲'},
      {'icon': Icons.grid_4x4, 'label': 'Puzzle 15', 'color': Colors.orange, 'emoji': '🧩'},
      {'icon': Icons.color_lens, 'label': 'Tebak Warna', 'color': Colors.green, 'emoji': '🎨'},
      {'icon': Icons.credit_card, 'label': 'Memory Card', 'color': Colors.amber, 'emoji': '🃏'},
    ];

    return SizedBox(
      height: 135,
      child: ListView.builder(
        scrollDirection: Axis.horizontal,
        physics: const BouncingScrollPhysics(),
        padding: const EdgeInsets.symmetric(horizontal: 16),
        itemCount: games.length,
        itemBuilder: (context, index) {
          final game = games[index];
          return _buildPremiumGameCard(game);
        },
      ),
    );
  }

  Widget _buildPremiumGameCard(Map<String, dynamic> game) {
    final Color color = game['color'] as Color;
    final IconData icon = game['icon'] as IconData;
    final String label = game['label'] as String;
    final String emoji = game['emoji'] as String;

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => const GamePage(),
          ),
        );
      },
      child: Container(
        width: 100,
        margin: const EdgeInsets.only(right: 12),
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [glassPrimary, glassSecondary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: color.withOpacity(0.12),
            width: 1.5,
          ),
          boxShadow: [
            BoxShadow(
              color: color.withOpacity(0.06),
              blurRadius: 10,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [color, color.withOpacity(0.4)],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
                borderRadius: BorderRadius.circular(14),
                boxShadow: [
                  BoxShadow(
                    color: color.withOpacity(0.25),
                    blurRadius: 8,
                    offset: const Offset(0, 3),
                  ),
                ],
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(emoji, style: const TextStyle(fontSize: 18)),
                  const SizedBox(width: 4),
                  Icon(icon, color: primaryWhite, size: 18),
                ],
              ),
            ),
            const SizedBox(height: 8),
            Text(
              label,
              style: const TextStyle(
                color: primaryWhite,
                fontSize: 10,
                fontWeight: FontWeight.w600,
                letterSpacing: 0.2,
              ),
              textAlign: TextAlign.center,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
            Container(
              margin: const EdgeInsets.only(top: 4),
              width: 24,
              height: 2,
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [color, color.withOpacity(0.3)],
                ),
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ============================================================
  // CUSTOM DRAWER
  // ============================================================
  Widget _buildCustomDrawer() {
    return Drawer(
      backgroundColor: bgPrimary,
      width: MediaQuery.of(context).size.width * 0.85,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.only(
          topRight: Radius.circular(0),
          bottomRight: Radius.circular(0),
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: 280,
            decoration: BoxDecoration(
              gradient: neonGradient,
              boxShadow: [
                BoxShadow(
                  color: accentNeon.withOpacity(0.2),
                  blurRadius: 30,
                ),
              ],
            ),
            child: SafeArea(
              child: Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Container(
                      width: 100,
                      height: 100,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                          color: primaryWhite.withOpacity(0.5),
                          width: 3,
                        ),
                        boxShadow: [
                          BoxShadow(
                            color: accentNeon.withOpacity(0.3),
                            blurRadius: 20,
                            spreadRadius: 5,
                          ),
                        ],
                      ),
                      child: ClipOval(
                        child: _profileImage != null
                            ? Image.file(_profileImage!, fit: BoxFit.cover)
                            : Container(
                                decoration: BoxDecoration(
                                  gradient: purpleGradient,
                                ),
                                child: Icon(
                                  FontAwesomeIcons.userAstronaut,
                                  size: 45,
                                  color: primaryWhite.withOpacity(0.9),
                                ),
                              ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Text(
                      username,
                      style: const TextStyle(
                        color: primaryWhite,
                        fontSize: 20,
                        fontWeight: FontWeight.w700,
                        letterSpacing: 0.5,
                      ),
                    ),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 5,
                      ),
                      decoration: BoxDecoration(
                        color: primaryWhite.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(20),
                        border: Border.all(
                          color: primaryWhite.withOpacity(0.2),
                        ),
                      ),
                      child: Text(
                        role.toUpperCase(),
                        style: const TextStyle(
                          color: primaryWhite,
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          letterSpacing: 1,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
          Expanded(
            child: Container(
              color: bgPrimary,
              child: ListView(
                padding: const EdgeInsets.symmetric(vertical: 20),
                children: [
                  if (role == "reseller")
                    _buildNeonMenuItem(
                      icon: Icons.storefront_rounded,
                      label: "Seller Page",
                      onTap: () => _onSidebarTabSelected(1),
                    ),
                  if (role == "admin")
                    _buildNeonMenuItem(
                      icon: Icons.admin_panel_settings_rounded,
                      label: "Admin Page",
                      onTap: () => _onSidebarTabSelected(2),
                    ),
                  if (role == "owner")
                    _buildNeonMenuItem(
                      icon: Icons.workspace_premium_rounded,
                      label: "Owner Page",
                      onTap: () => _onSidebarTabSelected(3),
                    ),
                  _buildNeonMenuItem(
                    icon: Icons.history_rounded,
                    label: "Riwayat Aktivitas",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) =>
                              RiwayatPage(sessionKey: sessionKey, role: role),
                        ),
                      );
                    },
                  ),
                  _buildNeonMenuItem(
                    icon: Icons.send_rounded,
                    label: "Manage Sender",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => BugSenderPage(
                            sessionKey: sessionKey,
                            username: username,
                            role: role,
                          ),
                        ),
                      );
                    },
                  ),
                  _buildNeonMenuItem(
                    icon: Icons.shopping_bag_rounded,
                    label: "Toko",
                    onTap: () {
                      Navigator.pop(context);
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const TokoPage(),
                        ),
                      );
                    },
                  ),
                  const Divider(
                    color: Colors.white10,
                    height: 32,
                    thickness: 0.5,
                  ),
                  _buildNeonMenuItem(
                    icon: Icons.logout_rounded,
                    label: "Log Out",
                    isLogout: true,
                    onTap: () async {
                      Navigator.pop(context);
                      final prefs = await SharedPreferences.getInstance();
                      await prefs.clear();
                      if (!mounted) return;
                      Navigator.of(context).pushAndRemoveUntil(
                        MaterialPageRoute(
                          builder: (context) => const LoginPage(),
                        ),
                        (route) => false,
                      );
                    },
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildNeonMenuItem({
    required IconData icon,
    required String label,
    required VoidCallback onTap,
    bool isLogout = false,
  }) {
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      decoration: BoxDecoration(
        gradient: isLogout
            ? LinearGradient(
                colors: [Color(0xFFE53935).withOpacity(0.1), Color(0xFFB71C1C).withOpacity(0.1)],
              )
            : LinearGradient(
                colors: [glassSecondary, glassPrimary],
              ),
        borderRadius: BorderRadius.circular(16),
        border: isLogout
            ? Border.all(color: Colors.red.withOpacity(0.2))
            : Border.all(color: glassBorder),
      ),
      child: ListTile(
        leading: Container(
          padding: const EdgeInsets.all(8),
          decoration: BoxDecoration(
            gradient: isLogout
                ? const LinearGradient(
                    colors: [Color(0xFFE53935), Color(0xFFB71C1C)],
                  )
                : neonGradient,
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(
            icon,
            color: primaryWhite,
            size: 20,
          ),
        ),
        title: Text(
          label,
          style: TextStyle(
            color: isLogout ? Colors.redAccent : primaryWhite,
            fontWeight: FontWeight.w600,
            fontSize: 14,
            letterSpacing: 0.3,
          ),
        ),
        trailing: isLogout
            ? null
            : Icon(Icons.chevron_right_rounded, color: softGrey, size: 20),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        onTap: onTap,
      ),
    );
  }

  // ============================================================
  // BUILD
  // ============================================================
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgPrimary,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 10),
          decoration: BoxDecoration(
            gradient: neonGradient,
            borderRadius: BorderRadius.circular(30),
            boxShadow: [
              BoxShadow(
                color: accentNeon.withOpacity(0.3),
                blurRadius: 10,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: Text(
            "✦ Viciousx",
            style: TextStyle(
              color: primaryWhite,
              fontWeight: FontWeight.w700,
              fontSize: 14,
              letterSpacing: 1.5,
            ),
          ),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        iconTheme: const IconThemeData(color: primaryWhite),
        actions: [
          Container(
            margin: const EdgeInsets.only(right: 8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [glassPrimary, glassSecondary],
              ),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: glassBorder),
            ),
            child: IconButton(
              icon: Icon(
                Icons.headset_mic_rounded,
                color: accentNeon,
                size: 20,
              ),
              tooltip: 'Customer Service',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(builder: (context) => const ContactPage()),
                );
              },
            ),
          ),
          Container(
            margin: const EdgeInsets.only(right: 12),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [glassPrimary, glassSecondary],
              ),
              borderRadius: BorderRadius.circular(14),
              border: Border.all(color: glassBorder),
            ),
            child: IconButton(
              icon: Icon(
                FontAwesomeIcons.circleUser,
                color: accentNeon,
                size: 20,
              ),
              tooltip: 'My Profile',
              onPressed: () {
                Navigator.push(
                  context,
                  MaterialPageRoute(
                    builder: (context) => ProfilePage(
                      username: username,
                      password: password,
                      role: role,
                      expiredDate: expiredDate,
                      sessionKey: sessionKey,
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      drawer: _buildCustomDrawer(),
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topLeft,
            radius: 1.5,
            colors: [
              accentNeon.withOpacity(0.05),
              bgPrimary,
              bgPrimary,
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
        ),
        child: CustomPaint(
          painter: _NeonGridPainter(),
          child: SafeArea(
            child: FadeTransition(
              opacity: _fadeAnimation,
              child: SlideTransition(
                position: _slideAnimation,
                child: _selectedPage,
              ),
            ),
          ),
        ),
      ),
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              bgSecondary.withOpacity(0.95),
              bgPrimary.withOpacity(0.95),
            ],
          ),
          border: Border(
            top: BorderSide(color: glassBorder),
          ),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(24),
            topRight: Radius.circular(24),
          ),
        ),
        child: BottomNavigationBar(
          backgroundColor: Colors.transparent,
          selectedItemColor: accentNeon,
          unselectedItemColor: softGrey,
          currentIndex: _bottomNavIndex,
          onTap: _onBottomNavTapped,
          type: BottomNavigationBarType.fixed,
          selectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.w700,
            fontSize: 11,
            letterSpacing: 0.5,
          ),
          unselectedLabelStyle: const TextStyle(fontSize: 11),
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.dashboard_rounded),
              label: "Home",
            ),
            BottomNavigationBarItem(
              icon: Icon(FontAwesomeIcons.whatsapp),
              label: "WhatsApp",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.notifications_active_rounded),
              label: "Info",
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.build_rounded),
              label: "Tools",
            ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _statsTimer?.cancel();
    _onlineTimer?.cancel();
    _channel?.sink.close(status.goingAway);
    _animationController.dispose();
    super.dispose();
  }
}

// ============================================================
// NEON GRID PAINTER
// ============================================================
class _NeonGridPainter extends CustomPainter {
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color accentPurple = Color(0xFF9C27B0);
  static const double gridSize = 30.0;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.02)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    for (double x = 0; x <= size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    for (double y = 0; y <= size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    final neonPaint = Paint()
      ..color = accentNeon.withOpacity(0.05)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final purplePaint = Paint()
      ..color = accentPurple.withOpacity(0.03)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    for (double x = 0; x <= size.width; x += gridSize * 5) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), neonPaint);
    }

    for (double y = 0; y <= size.height; y += gridSize * 5) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), purplePaint);
    }

    final dotPaint = Paint()
      ..color = accentNeon.withOpacity(0.08)
      ..style = PaintingStyle.fill;

    for (double x = 0; x <= size.width; x += gridSize) {
      for (double y = 0; y <= size.height; y += gridSize) {
        canvas.drawCircle(Offset(x, y), 1.5, dotPaint);
      }
    }

    final diagPaint = Paint()
      ..color = accentNeon.withOpacity(0.015)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;

    for (double i = -size.height; i < size.width + size.height; i += 60) {
      canvas.drawLine(
        Offset(i, 0),
        Offset(i + size.height, size.height),
        diagPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}