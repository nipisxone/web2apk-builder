// game_page.dart - VERSION BERSIH (TANPA SOUND & VIBRASI)
import 'dart:math';
import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// ============================================================
// GAME SYSTEM GLOBAL
// ============================================================
class GameSystem {
  static const String PREFS_KEY = 'game_data';
  
  static Future<Map<String, dynamic>> loadData() async {
    final prefs = await SharedPreferences.getInstance();
    final data = prefs.getString(PREFS_KEY);
    if (data != null) {
      try {
        return Map<String, dynamic>.from(jsonDecode(data));
      } catch (e) {
        return _defaultData();
      }
    }
    return _defaultData();
  }

  static Map<String, dynamic> _defaultData() {
    return {
      'coins': 0,
      'level': 1,
      'xp': 0,
      'xpToNext': 100,
      'badges': [],
      'stats': {
        'totalWins': 0,
        'totalLoses': 0,
        'gamesPlayed': 0,
      },
      'dailyReward': {
        'lastClaim': '',
        'streak': 0,
      },
      'gameStats': {
        'tebakAngka': {'wins': 0, 'loses': 0, 'highScore': 0},
        'ticTacToe': {'wins': 0, 'loses': 0, 'draws': 0},
        'dadu': {'wins': 0, 'loses': 0},
        'puzzle': {'bestTime': 0},
        'tebakWarna': {'highScore': 0},
        'memoryCard': {'bestScore': 0},
      }
    };
  }

  static Future<void> saveData(Map<String, dynamic> data) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(PREFS_KEY, jsonEncode(data));
  }

  static Future<void> addXP(int amount) async {
    final data = await loadData();
    data['xp'] = (data['xp'] ?? 0) + amount;
    while (data['xp'] >= data['xpToNext']) {
      data['xp'] -= data['xpToNext'];
      data['level'] = (data['level'] ?? 1) + 1;
      data['xpToNext'] = ((data['xpToNext'] ?? 100) * 1.2).round();
      if (data['level'] % 5 == 0) {
        data['badges'].add('🎖️ Level ${data['level']}');
      }
    }
    await saveData(data);
  }

  static Future<void> addCoins(int amount) async {
    final data = await loadData();
    data['coins'] = (data['coins'] ?? 0) + amount;
    if (data['coins'] >= 100 && !data['badges'].contains('💰 100 Coins')) {
      data['badges'].add('💰 100 Coins');
    }
    if (data['coins'] >= 1000 && !data['badges'].contains('💰 1000 Coins')) {
      data['badges'].add('💰 1000 Coins');
    }
    await saveData(data);
  }
}

// ============================================================
// GAME PAGE MAIN
// ============================================================
class GamePage extends StatefulWidget {
  const GamePage({super.key});

  @override
  State<GamePage> createState() => _GamePageState();
}

class _GamePageState extends State<GamePage> with SingleTickerProviderStateMixin {
  int _selectedGame = 0;
  Map<String, dynamic> _gameData = {};
  bool _isLoading = true;

  static const Color bgPrimary = Color(0xFF080C1A);
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color accentPurple = Color(0xFF9C27B0);
  static const Color accentPink = Color(0xFFEC4899);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF8A99B0);

  Color get glassPrimary => const Color(0x1AFFFFFF);
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);

  LinearGradient get neonGradient => const LinearGradient(
        colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  LinearGradient get goldGradient => const LinearGradient(
        colors: [Color(0xFFFFD700), Color(0xFFFFA500)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  final List<Map<String, dynamic>> _games = [
    {'icon': Icons.numbers, 'name': 'Tebak Angka', 'color': accentNeon, 'emoji': '🔢'},
    {'icon': Icons.grid_on, 'name': 'Tic Tac Toe', 'color': accentPurple, 'emoji': '❌'},
    {'icon': Icons.casino, 'name': 'Dadu', 'color': accentPink, 'emoji': '🎲'},
    {'icon': Icons.grid_4x4, 'name': 'Puzzle', 'color': Colors.orange, 'emoji': '🧩'},
    {'icon': Icons.color_lens, 'name': 'Tebak Warna', 'color': Colors.green, 'emoji': '🎨'},
    {'icon': Icons.credit_card, 'name': 'Memory Card', 'color': Colors.amber, 'emoji': '🃏'},
  ];

  @override
  void initState() {
    super.initState();
    _loadGameData();
  }

  Future<void> _loadGameData() async {
    final data = await GameSystem.loadData();
    setState(() {
      _gameData = data;
      _isLoading = false;
    });
  }

  Future<void> _refreshData() async {
    final data = await GameSystem.loadData();
    setState(() {
      _gameData = data;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgPrimary,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [glassPrimary, glassSecondary]),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: glassBorder),
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: accentNeon, size: 18),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        title: Container(
          padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
          decoration: BoxDecoration(
            gradient: neonGradient,
            borderRadius: BorderRadius.circular(24),
            boxShadow: [
              BoxShadow(color: accentNeon.withOpacity(0.3), blurRadius: 10),
            ],
          ),
          child: const Text(
            "✦ GAME ZONE",
            style: TextStyle(
              color: primaryWhite,
              fontWeight: FontWeight.bold,
              fontSize: 14,
              letterSpacing: 1,
            ),
          ),
        ),
        actions: [
          if (!_isLoading) ...[
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              margin: const EdgeInsets.only(right: 8),
              decoration: BoxDecoration(
                gradient: goldGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  const Text('🪙', style: TextStyle(fontSize: 14)),
                  const SizedBox(width: 4),
                  Text(
                    '${_gameData['coins'] ?? 0}',
                    style: const TextStyle(
                      color: Colors.black,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
              margin: const EdgeInsets.only(right: 12),
              decoration: BoxDecoration(
                gradient: neonGradient,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Text(
                'Lv.${_gameData['level'] ?? 1}',
                style: const TextStyle(
                  color: primaryWhite,
                  fontWeight: FontWeight.bold,
                  fontSize: 11,
                ),
              ),
            ),
          ],
        ],
      ),
      body: _isLoading
          ? const Center(
              child: CircularProgressIndicator(color: accentNeon),
            )
          : Column(
              children: [
                Container(
                  padding: const EdgeInsets.all(16),
                  child: GridView.builder(
                    shrinkWrap: true,
                    physics: const NeverScrollableScrollPhysics(),
                    gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 12,
                      mainAxisSpacing: 12,
                      childAspectRatio: 1.1,
                    ),
                    itemCount: _games.length,
                    itemBuilder: (context, index) {
                      final game = _games[index];
                      final isSelected = _selectedGame == index;
                      return GestureDetector(
                        onTap: () {
                          setState(() => _selectedGame = index);
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: isSelected
                                ? neonGradient
                                : LinearGradient(
                                    colors: [glassPrimary, glassSecondary],
                                    begin: Alignment.topLeft,
                                    end: Alignment.bottomRight,
                                  ),
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: isSelected ? accentNeon : glassBorder,
                              width: isSelected ? 2 : 1,
                            ),
                            boxShadow: isSelected
                                ? [BoxShadow(color: accentNeon.withOpacity(0.3), blurRadius: 15)]
                                : [],
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              Text(game['emoji'], style: const TextStyle(fontSize: 24)),
                              const SizedBox(height: 4),
                              Icon(
                                game['icon'],
                                color: isSelected ? primaryWhite : game['color'],
                                size: 24,
                              ),
                              const SizedBox(height: 6),
                              Text(
                                game['name'],
                                style: TextStyle(
                                  color: isSelected ? primaryWhite : softGrey,
                                  fontSize: 10,
                                  fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                                ),
                                textAlign: TextAlign.center,
                                maxLines: 2,
                                overflow: TextOverflow.ellipsis,
                              ),
                              if (isSelected)
                                Container(
                                  margin: const EdgeInsets.only(top: 4),
                                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                                  decoration: BoxDecoration(
                                    color: primaryWhite.withOpacity(0.2),
                                    borderRadius: BorderRadius.circular(8),
                                  ),
                                  child: const Text(
                                    '▶ PLAY',
                                    style: TextStyle(
                                      color: primaryWhite,
                                      fontSize: 8,
                                      fontWeight: FontWeight.bold,
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
                if (!_isLoading) ...[
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 20),
                    child: Row(
                      children: [
                        const Text('⚡', style: TextStyle(fontSize: 12)),
                        const SizedBox(width: 8),
                        Expanded(
                          child: ClipRRect(
                            borderRadius: BorderRadius.circular(10),
                            child: LinearProgressIndicator(
                              value: (_gameData['xp'] ?? 0) / (_gameData['xpToNext'] ?? 100),
                              backgroundColor: Colors.white10,
                              valueColor: AlwaysStoppedAnimation(accentNeon),
                              minHeight: 6,
                            ),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Text(
                          '${(((_gameData['xp'] ?? 0) / (_gameData['xpToNext'] ?? 100)) * 100).round()}%',
                          style: const TextStyle(
                            color: softGrey,
                            fontSize: 10,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                ],
                Expanded(
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 16),
                    decoration: BoxDecoration(
                      gradient: LinearGradient(
                        colors: [glassPrimary, glassSecondary],
                        begin: Alignment.topLeft,
                        end: Alignment.bottomRight,
                      ),
                      borderRadius: BorderRadius.circular(20),
                      border: Border.all(color: glassBorder),
                    ),
                    child: IndexedStack(
                      index: _selectedGame,
                      children: const [
                        TebakAngkaGame(),
                        TicTacToeGame(),
                        DaduGame(),
                        PuzzleGame(),
                        TebakWarnaGame(),
                        MemoryCardGame(),
                      ],
                    ),
                  ),
                ),
              ],
            ),
    );
  }
}

// ============================================================
// GAME 1: TEBAK ANGKA
// ============================================================
class TebakAngkaGame extends StatefulWidget {
  const TebakAngkaGame({super.key});

  @override
  State<TebakAngkaGame> createState() => _TebakAngkaGameState();
}

class _TebakAngkaGameState extends State<TebakAngkaGame> {
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF8A99B0);
  
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);
  
  LinearGradient get neonGradient => const LinearGradient(
        colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  final TextEditingController _inputController = TextEditingController();
  final Random _random = Random();
  
  int _targetNumber = 0;
  int _attempts = 0;
  int _maxAttempts = 7;
  String _message = 'Tebak angka antara 1-100';
  String _hint = '';
  bool _isGameOver = false;
  bool _isWin = false;
  List<String> _history = [];
  
  String _difficulty = 'Medium';
  int _timer = 30;
  Timer? _timerTimer;
  int _highScore = 0;
  bool _isTimerRunning = false;
  final List<String> _difficulties = ['Easy', 'Medium', 'Hard'];

  @override
  void initState() {
    super.initState();
    _loadHighScore();
    _resetGame();
  }

  Future<void> _loadHighScore() async {
    final data = await GameSystem.loadData();
    setState(() {
      _highScore = data['gameStats']['tebakAngka']['highScore'] ?? 0;
    });
  }

  void _resetGame() {
    _timerTimer?.cancel();
    setState(() {
      int max = _difficulty == 'Easy' ? 50 : _difficulty == 'Medium' ? 100 : 200;
      _targetNumber = _random.nextInt(max) + 1;
      _attempts = 0;
      _maxAttempts = _difficulty == 'Easy' ? 10 : _difficulty == 'Medium' ? 7 : 5;
      _message = 'Tebak angka antara 1-$max';
      _hint = '';
      _isGameOver = false;
      _isWin = false;
      _history = [];
      _inputController.clear();
      _timer = 30;
      _isTimerRunning = false;
    });
    _loadHighScore();
  }

  void _startTimer() {
    if (_isTimerRunning) return;
    setState(() {
      _isTimerRunning = true;
      _timer = 30;
    });
    _timerTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _timer--;
        if (_timer <= 0) {
          timer.cancel();
          _isTimerRunning = false;
          _endGame(false, '⏰ Waktu Habis!');
        }
      });
    });
  }

  void _guessNumber() {
    if (_isGameOver) return;
    if (!_isTimerRunning) _startTimer();
    
    final input = _inputController.text.trim();
    if (input.isEmpty) {
      setState(() => _message = 'Masukkan angka!');
      return;
    }
    final guess = int.tryParse(input);
    int max = _difficulty == 'Easy' ? 50 : _difficulty == 'Medium' ? 100 : 200;
    if (guess == null || guess < 1 || guess > max) {
      setState(() => _message = 'Masukkan angka 1-$max!');
      return;
    }

    setState(() {
      _attempts++;
      _history.add('$guess');
      
      if (guess == _targetNumber) {
        _endGame(true, '🎉 BENAR! Angka nya adalah $_targetNumber!');
        _hint = 'Selamat! $_attempts percobaan!';
        _saveHighScoreIfBetter();
      } else if (guess < _targetNumber) {
        if (_attempts >= 3) {
          int diff = _targetNumber - guess;
          if (diff < 10) _hint = '📈 Sedikit lebih TINGGI';
          else if (diff < 30) _hint = '📈 Lumayan TINGGI';
          else _hint = '📈 Jauh lebih TINGGI';
        } else {
          _hint = '📈 Terlalu RENDAH';
        }
        _message = 'Coba angka yang lebih besar';
      } else {
        if (_attempts >= 3) {
          int diff = guess - _targetNumber;
          if (diff < 10) _hint = '📉 Sedikit lebih RENDAH';
          else if (diff < 30) _hint = '📉 Lumayan RENDAH';
          else _hint = '📉 Jauh lebih RENDAH';
        } else {
          _hint = '📉 Terlalu TINGGI';
        }
        _message = 'Coba angka yang lebih kecil';
      }
      
      if (_attempts >= _maxAttempts && !_isGameOver) {
        _endGame(false, '😔 Game Over! Angka nya adalah $_targetNumber');
        _hint = 'Kesempatan habis!';
      }
    });
    _inputController.clear();
  }

  void _endGame(bool win, String message) {
    _timerTimer?.cancel();
    _isTimerRunning = false;
    setState(() {
      _isGameOver = true;
      _isWin = win;
      _message = message;
    });
    if (win) {
      GameSystem.addCoins(10 + _attempts);
      GameSystem.addXP(20 + _attempts * 2);
      _updateStats(true);
    } else {
      _updateStats(false);
    }
  }

  void _saveHighScoreIfBetter() {
    int score = max(0, 100 - _attempts * 3 + _timer * 2);
    if (score > _highScore) {
      _highScore = score;
      _saveHighScore();
    }
  }

  Future<void> _saveHighScore() async {
    final data = await GameSystem.loadData();
    data['gameStats']['tebakAngka']['highScore'] = _highScore;
    await GameSystem.saveData(data);
  }

  Future<void> _updateStats(bool win) async {
    final data = await GameSystem.loadData();
    data['stats']['gamesPlayed'] = (data['stats']['gamesPlayed'] ?? 0) + 1;
    if (win) {
      data['stats']['totalWins'] = (data['stats']['totalWins'] ?? 0) + 1;
      data['gameStats']['tebakAngka']['wins'] = (data['gameStats']['tebakAngka']['wins'] ?? 0) + 1;
    } else {
      data['stats']['totalLoses'] = (data['stats']['totalLoses'] ?? 0) + 1;
      data['gameStats']['tebakAngka']['loses'] = (data['gameStats']['tebakAngka']['loses'] ?? 0) + 1;
    }
    await GameSystem.saveData(data);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: glassSecondary,
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: glassBorder),
                ),
                child: DropdownButton<String>(
                  value: _difficulty,
                  dropdownColor: const Color(0xFF0F1426),
                  underline: const SizedBox(),
                  style: const TextStyle(color: primaryWhite, fontSize: 11),
                  icon: const Icon(Icons.arrow_drop_down, color: accentNeon, size: 18),
                  onChanged: (value) {
                    if (_isGameOver || _attempts == 0) {
                      setState(() => _difficulty = value!);
                      _resetGame();
                    }
                  },
                  items: _difficulties.map((d) => DropdownMenuItem(
                    value: d,
                    child: Text(d, style: const TextStyle(fontSize: 11)),
                  )).toList(),
                ),
              ),
              if (_isTimerRunning || _isGameOver)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: _timer < 10 ? Colors.red.withOpacity(0.2) : accentNeon.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: _timer < 10 ? Colors.red.withOpacity(0.3) : accentNeon.withOpacity(0.2),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(Icons.timer, color: _timer < 10 ? Colors.red : accentNeon, size: 14),
                      const SizedBox(width: 4),
                      Text(
                        '${_timer}s',
                        style: TextStyle(
                          color: _timer < 10 ? Colors.red : accentNeon,
                          fontSize: 11,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ],
                  ),
                ),
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  gradient: const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFA500)]),
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Row(
                  children: [
                    const Text('🏆', style: TextStyle(fontSize: 12)),
                    const SizedBox(width: 4),
                    Text(
                      '$_highScore',
                      style: const TextStyle(
                        color: Colors.black,
                        fontWeight: FontWeight.bold,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Percobaan: $_attempts / $_maxAttempts',
                style: TextStyle(color: accentNeon, fontSize: 11, fontWeight: FontWeight.bold),
              ),
              Container(
                padding: const EdgeInsets.all(6),
                decoration: BoxDecoration(
                  gradient: neonGradient,
                  shape: BoxShape.circle,
                ),
                child: Text(
                  '$_attempts',
                  style: const TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 12),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: glassSecondary,
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: glassBorder),
            ),
            child: Column(
              children: [
                Text(
                  _hint.isEmpty ? '🤔' : _hint,
                  style: TextStyle(
                    color: _hint.contains('lebih') ? accentNeon : 
                           _hint.contains('Selamat') ? Colors.green : 
                           _hint.contains('Tinggi') || _hint.contains('RENDAH') ? accentNeon : 
                           Colors.green,
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  _message,
                  style: TextStyle(
                    color: _isGameOver ? (_isWin ? Colors.green : Colors.red) : primaryWhite,
                    fontSize: 12,
                  ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          const SizedBox(height: 8),
          if (_history.isNotEmpty)
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: glassSecondary,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: glassBorder),
              ),
              child: Wrap(
                spacing: 4,
                runSpacing: 4,
                children: _history.map((number) {
                  final isCorrect = int.parse(number) == _targetNumber && _isWin;
                  return Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: isCorrect ? Colors.green : accentNeon.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(
                        color: isCorrect ? Colors.green : accentNeon.withOpacity(0.2),
                      ),
                    ),
                    child: Text(
                      number,
                      style: TextStyle(
                        color: isCorrect ? Colors.green : accentNeon,
                        fontSize: 11,
                      ),
                    ),
                  );
                }).toList(),
              ),
            ),
          const Spacer(),
          if (!_isGameOver) ...[
            Container(
              decoration: BoxDecoration(
                color: glassSecondary,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: glassBorder),
              ),
              child: TextField(
                controller: _inputController,
                style: const TextStyle(color: primaryWhite),
                keyboardType: TextInputType.number,
                decoration: const InputDecoration(
                  hintText: 'Masukkan angka...',
                  hintStyle: TextStyle(color: softGrey),
                  border: InputBorder.none,
                  contentPadding: EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                ),
                onSubmitted: (_) => _guessNumber(),
              ),
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(
                  child: Container(
                    height: 36,
                    decoration: BoxDecoration(
                      gradient: neonGradient,
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: ElevatedButton(
                      onPressed: _guessNumber,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                      child: const Text(
                        'TEBAK',
                        style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 12),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  height: 36,
                  width: 36,
                  decoration: BoxDecoration(
                    color: glassSecondary,
                    borderRadius: BorderRadius.circular(12),
                    border: Border.all(color: glassBorder),
                  ),
                  child: IconButton(
                    icon: const Icon(Icons.refresh, color: accentNeon, size: 18),
                    onPressed: _resetGame,
                  ),
                ),
              ],
            ),
          ],
          if (_isGameOver) ...[
            Container(
              padding: const EdgeInsets.all(10),
              decoration: BoxDecoration(
                color: (_isWin ? Colors.green : Colors.red).withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: (_isWin ? Colors.green : Colors.red).withOpacity(0.3),
                ),
              ),
              child: Column(
                children: [
                  Icon(
                    _isWin ? Icons.emoji_events : Icons.sentiment_dissatisfied,
                    color: _isWin ? Colors.green : Colors.red,
                    size: 28,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    _isWin ? '🎉 Selamat! +${10 + _attempts} 🪙' : '😔 Coba Lagi!',
                    style: TextStyle(
                      color: _isWin ? Colors.green : Colors.red,
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Container(
                    height: 32,
                    decoration: BoxDecoration(
                      gradient: neonGradient,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: ElevatedButton(
                      onPressed: _resetGame,
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: const Text(
                        'MAIN LAGI',
                        style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 11),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timerTimer?.cancel();
    _inputController.dispose();
    super.dispose();
  }
}

// ============================================================
// GAME 2: TIC TAC TOE
// ============================================================
class TicTacToeGame extends StatefulWidget {
  const TicTacToeGame({super.key});

  @override
  State<TicTacToeGame> createState() => _TicTacToeGameState();
}

class _TicTacToeGameState extends State<TicTacToeGame> {
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color accentPurple = Color(0xFF9C27B0);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);
  LinearGradient get neonGradient => const LinearGradient(
        colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  List<String> _board = List.filled(9, '');
  String _currentPlayer = 'X';
  String _winner = '';
  bool _isGameOver = false;
  int _moveCount = 0;
  bool _isVsBot = true;
  String _difficulty = 'Medium';
  List<String> _difficulties = ['Easy', 'Medium', 'Hard'];
  int _wins = 0, _loses = 0, _draws = 0;
  bool _isBotThinking = false;

  @override
  void initState() {
    super.initState();
    _loadStats();
  }

  Future<void> _loadStats() async {
    final data = await GameSystem.loadData();
    setState(() {
      _wins = data['gameStats']['ticTacToe']['wins'] ?? 0;
      _loses = data['gameStats']['ticTacToe']['loses'] ?? 0;
      _draws = data['gameStats']['ticTacToe']['draws'] ?? 0;
    });
  }

  void _resetGame() {
    setState(() {
      _board = List.filled(9, '');
      _currentPlayer = 'X';
      _winner = '';
      _isGameOver = false;
      _moveCount = 0;
      _isBotThinking = false;
    });
    if (_isVsBot && _currentPlayer == 'O') {
      _botMove();
    }
  }

  void _makeMove(int index) {
    if (_board[index].isNotEmpty || _isGameOver || _isBotThinking) return;
    if (_isVsBot && _currentPlayer == 'O') return;

    setState(() {
      _board[index] = _currentPlayer;
      _moveCount++;
      _checkWinner();
      if (!_isGameOver) {
        _currentPlayer = _currentPlayer == 'X' ? 'O' : 'X';
        if (_isVsBot && !_isGameOver && _currentPlayer == 'O') {
          _botMove();
        }
      }
    });
  }

  void _botMove() {
    if (_isGameOver || _isBotThinking) return;
    _isBotThinking = true;

    Future.delayed(const Duration(milliseconds: 500), () {
      if (_isGameOver) return;
      int move = _getBestMove();
      if (move != -1) {
        setState(() {
          _board[move] = 'O';
          _moveCount++;
          _checkWinner();
          if (!_isGameOver) {
            _currentPlayer = 'X';
          }
          _isBotThinking = false;
        });
      }
    });
  }

  int _getBestMove() {
    int diff = _difficulties.indexOf(_difficulty);
    
    for (int i = 0; i < 9; i++) {
      if (_board[i].isEmpty) {
        _board[i] = 'O';
        if (_checkWinnerFor('O')) {
          _board[i] = '';
          return i;
        }
        _board[i] = '';
      }
    }

    if (diff >= 1) {
      for (int i = 0; i < 9; i++) {
        if (_board[i].isEmpty) {
          _board[i] = 'X';
          if (_checkWinnerFor('X')) {
            _board[i] = '';
            return i;
          }
          _board[i] = '';
        }
      }
    }

    if (diff >= 2 && _board[4].isEmpty) return 4;

    List<int> empty = [];
    for (int i = 0; i < 9; i++) {
      if (_board[i].isEmpty) empty.add(i);
    }
    if (empty.isEmpty) return -1;
    return empty[Random().nextInt(empty.length)];
  }

  bool _checkWinnerFor(String player) {
    const winPatterns = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6],
    ];
    for (var p in winPatterns) {
      if (_board[p[0]] == player && _board[p[1]] == player && _board[p[2]] == player) {
        return true;
      }
    }
    return false;
  }

  void _checkWinner() {
    const winPatterns = [
      [0, 1, 2], [3, 4, 5], [6, 7, 8],
      [0, 3, 6], [1, 4, 7], [2, 5, 8],
      [0, 4, 8], [2, 4, 6],
    ];
    for (var pattern in winPatterns) {
      final a = _board[pattern[0]];
      final b = _board[pattern[1]];
      final c = _board[pattern[2]];
      if (a.isNotEmpty && a == b && b == c) {
        _endGame(a);
        return;
      }
    }
    if (_moveCount == 9) {
      _endGame('Draw');
    }
  }

  void _endGame(String winner) {
    setState(() {
      _winner = winner;
      _isGameOver = true;
    });
    if (winner == 'X') {
      GameSystem.addCoins(15);
      GameSystem.addXP(25);
      setState(() => _wins++);
      _updateStats('win');
    } else if (winner == 'O') {
      setState(() => _loses++);
      _updateStats('lose');
    } else {
      setState(() => _draws++);
      _updateStats('draw');
    }
  }

  Future<void> _updateStats(String result) async {
    final data = await GameSystem.loadData();
    data['stats']['gamesPlayed'] = (data['stats']['gamesPlayed'] ?? 0) + 1;
    if (result == 'win') {
      data['stats']['totalWins'] = (data['stats']['totalWins'] ?? 0) + 1;
      data['gameStats']['ticTacToe']['wins'] = (data['gameStats']['ticTacToe']['wins'] ?? 0) + 1;
    } else if (result == 'lose') {
      data['stats']['totalLoses'] = (data['stats']['totalLoses'] ?? 0) + 1;
      data['gameStats']['ticTacToe']['loses'] = (data['gameStats']['ticTacToe']['loses'] ?? 0) + 1;
    } else {
      data['gameStats']['ticTacToe']['draws'] = (data['gameStats']['ticTacToe']['draws'] ?? 0) + 1;
    }
    await GameSystem.saveData(data);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              GestureDetector(
                onTap: () {
                  setState(() => _isVsBot = !_isVsBot);
                  _resetGame();
                },
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: glassSecondary,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: glassBorder),
                  ),
                  child: Text(
                    _isVsBot ? '🤖 VS BOT' : '👥 VS PLAYER',
                    style: TextStyle(
                      color: accentNeon,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              Row(
                children: [
                  _buildStat('🏆', '$_wins', Colors.green),
                  const SizedBox(width: 4),
                  _buildStat('⚖️', '$_draws', Colors.orange),
                  const SizedBox(width: 4),
                  _buildStat('💀', '$_loses', Colors.red),
                ],
              ),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(4),
                    decoration: BoxDecoration(
                      gradient: neonGradient,
                      shape: BoxShape.circle,
                    ),
                    child: Text(
                      _currentPlayer,
                      style: const TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 12),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Text(
                    _isGameOver ? 'Selesai' : 'Giliran $_currentPlayer',
                    style: TextStyle(color: primaryWhite, fontSize: 11),
                  ),
                ],
              ),
              if (_isVsBot)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                  decoration: BoxDecoration(
                    color: glassSecondary,
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: glassBorder),
                  ),
                  child: DropdownButton<String>(
                    value: _difficulty,
                    dropdownColor: const Color(0xFF0F1426),
                    underline: const SizedBox(),
                    style: const TextStyle(color: primaryWhite, fontSize: 9),
                    icon: const Icon(Icons.arrow_drop_down, color: accentNeon, size: 16),
                    onChanged: (value) {
                      setState(() => _difficulty = value!);
                      _resetGame();
                    },
                    items: _difficulties.map((d) => DropdownMenuItem(
                      value: d,
                      child: Text(d, style: const TextStyle(fontSize: 9)),
                    )).toList(),
                  ),
                ),
              if (_isGameOver)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: _winner == 'Draw' ? Colors.orange.withOpacity(0.2) : Colors.green.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(
                      color: _winner == 'Draw' ? Colors.orange.withOpacity(0.3) : Colors.green.withOpacity(0.3),
                    ),
                  ),
                  child: Text(
                    _winner == 'Draw' ? '⚖️ Draw' : '🏆 $_winner',
                    style: TextStyle(
                      color: _winner == 'Draw' ? Colors.orange : Colors.green,
                      fontSize: 9,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3,
                crossAxisSpacing: 6,
                mainAxisSpacing: 6,
              ),
              itemCount: 9,
              itemBuilder: (context, index) {
                final char = _board[index];
                final isWinCell = _isGameOver && char.isNotEmpty && 
                  (_winner == 'X' && char == 'X' || _winner == 'O' && char == 'O');
                return GestureDetector(
                  onTap: () => _makeMove(index),
                  child: Container(
                    decoration: BoxDecoration(
                      color: char.isNotEmpty
                          ? (char == 'X' ? accentNeon.withOpacity(0.15) : accentPurple.withOpacity(0.15))
                          : glassSecondary,
                      borderRadius: BorderRadius.circular(10),
                      border: Border.all(
                        color: isWinCell ? Colors.green : 
                               char.isNotEmpty ? (char == 'X' ? accentNeon : accentPurple).withOpacity(0.3) : glassBorder,
                        width: isWinCell ? 3 : 1,
                      ),
                      boxShadow: isWinCell ? [
                        BoxShadow(color: Colors.green.withOpacity(0.3), blurRadius: 10),
                      ] : [],
                    ),
                    child: Center(
                      child: Text(
                        char,
                        style: TextStyle(
                          color: char == 'X' ? accentNeon : accentPurple,
                          fontSize: 34,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 6),
          Container(
            height: 36,
            decoration: BoxDecoration(
              gradient: neonGradient,
              borderRadius: BorderRadius.circular(10),
            ),
            child: ElevatedButton(
              onPressed: _resetGame,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text(
                'RESET',
                style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 11),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStat(String emoji, String value, Color color) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(4),
      ),
      child: Row(
        children: [
          Text(emoji, style: const TextStyle(fontSize: 10)),
          const SizedBox(width: 2),
          Text(
            value,
            style: TextStyle(color: color, fontSize: 10, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }
}

// ============================================================
// GAME 3: DADU
// ============================================================
class DaduGame extends StatefulWidget {
  const DaduGame({super.key});

  @override
  State<DaduGame> createState() => _DaduGameState();
}

class _DaduGameState extends State<DaduGame> with SingleTickerProviderStateMixin {
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color accentPurple = Color(0xFF9C27B0);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF8A99B0);
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);
  LinearGradient get neonGradient => const LinearGradient(
        colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  int _diceValue = 1;
  bool _isRolling = false;
  late AnimationController _animationController;
  late Animation<double> _rotationAnimation;
  final List<int> _history = [];
  final List<String> _diceEmojis = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];
  
  bool _guessMode = false;
  int _guessNumber = 0;
  int _score = 0;
  int _betAmount = 0;

  @override
  void initState() {
    super.initState();
    _animationController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _rotationAnimation = Tween<double>(begin: 0, end: 2 * 3.14159 * 2).animate(
      CurvedAnimation(parent: _animationController, curve: Curves.easeOut),
    );
    _loadStats();
  }

  Future<void> _loadStats() async {
    final data = await GameSystem.loadData();
    setState(() {
      _score = data['gameStats']['dadu']['wins'] ?? 0;
    });
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  void _rollDice() {
    if (_isRolling) return;
    if (_guessMode && _guessNumber == 0) {
      _showMessage('Masukkan tebakan dulu!');
      return;
    }
    
    setState(() => _isRolling = true);
    _animationController.forward(from: 0);
    final random = Random();
    int newValue;
    do {
      newValue = random.nextInt(6) + 1;
    } while (newValue == _diceValue && _history.isNotEmpty);

    Future.delayed(const Duration(milliseconds: 500), () {
      setState(() {
        _diceValue = newValue;
        _isRolling = false;
        _history.add(newValue);
        if (_history.length > 10) _history.removeAt(0);
        
        if (_guessMode) {
          if (newValue == _guessNumber) {
            int reward = 10 + _betAmount;
            GameSystem.addCoins(reward);
            GameSystem.addXP(10);
            _score++;
            _showMessage('🎉 BENAR! +$reward 🪙');
          } else {
            _showMessage('😔 Salah! Angka: $newValue');
          }
        }
      });
      _animationController.reset();
    });
  }

  void _showMessage(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(msg, style: const TextStyle(color: primaryWhite)),
        backgroundColor: const Color(0xFF0F1426),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              GestureDetector(
                onTap: () => setState(() {
                  _guessMode = !_guessMode;
                  _guessNumber = 0;
                }),
                child: Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    gradient: _guessMode ? neonGradient : 
                      LinearGradient(colors: [glassSecondary, glassSecondary]),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: glassBorder),
                  ),
                  child: Text(
                    _guessMode ? '🎯 TEBAK' : '🎲 NORMAL',
                    style: TextStyle(
                      color: _guessMode ? primaryWhite : softGrey,
                      fontSize: 10,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
              if (_guessMode)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                  decoration: BoxDecoration(
                    color: accentNeon.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: accentNeon.withOpacity(0.2)),
                  ),
                  child: Text(
                    'Skor: $_score',
                    style: TextStyle(color: accentNeon, fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 6),
          Expanded(
            child: Center(
              child: AnimatedBuilder(
                animation: _rotationAnimation,
                builder: (context, child) {
                  return Transform.rotate(
                    angle: _isRolling ? _rotationAnimation.value : 0,
                    child: Column(
                      children: [
                        Text(
                          _diceEmojis[_diceValue - 1],
                          style: const TextStyle(fontSize: 80),
                        ),
                        const SizedBox(height: 4),
                        Text(
                          '$_diceValue',
                          style: const TextStyle(
                            color: primaryWhite,
                            fontSize: 18,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  );
                },
              ),
            ),
          ),
          if (_guessMode && !_isRolling) ...[
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 80,
                  decoration: BoxDecoration(
                    color: glassSecondary,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: glassBorder),
                  ),
                  child: TextField(
                    style: const TextStyle(color: primaryWhite),
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    decoration: const InputDecoration(
                      hintText: '1-6',
                      hintStyle: TextStyle(color: softGrey),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 8),
                    ),
                    onChanged: (value) {
                      final guess = int.tryParse(value);
                      if (guess != null && guess >= 1 && guess <= 6) {
                        setState(() => _guessNumber = guess);
                      }
                    },
                  ),
                ),
                const SizedBox(width: 6),
                Container(
                  width: 60,
                  decoration: BoxDecoration(
                    color: glassSecondary,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(color: glassBorder),
                  ),
                  child: TextField(
                    style: const TextStyle(color: primaryWhite),
                    keyboardType: TextInputType.number,
                    textAlign: TextAlign.center,
                    decoration: const InputDecoration(
                      hintText: 'Bet',
                      hintStyle: TextStyle(color: softGrey),
                      border: InputBorder.none,
                      contentPadding: EdgeInsets.symmetric(vertical: 8),
                    ),
                    onChanged: (value) {
                      final bet = int.tryParse(value);
                      if (bet != null && bet > 0) {
                        setState(() => _betAmount = bet);
                      }
                    },
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
          ],
          Container(
            height: 42,
            decoration: BoxDecoration(
              gradient: neonGradient,
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(color: accentNeon.withOpacity(0.3), blurRadius: 15),
                BoxShadow(color: accentPurple.withOpacity(0.2), blurRadius: 30),
              ],
            ),
            child: ElevatedButton(
              onPressed: _isRolling ? null : _rollDice,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(
                    _isRolling ? Icons.hourglass_top : Icons.casino,
                    color: primaryWhite,
                    size: 18,
                  ),
                  const SizedBox(width: 6),
                  Text(
                    _isRolling ? 'MENGOCEK...' : 
                    (_guessMode && _guessNumber > 0 ? 'TEBAK & LEMPAR' : 'LEMPAR DADU'),
                    style: const TextStyle(
                      color: primaryWhite,
                      fontWeight: FontWeight.bold,
                      fontSize: 12,
                    ),
                  ),
                ],
              ),
            ),
          ),
          if (_history.isNotEmpty) ...[
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.all(6),
              decoration: BoxDecoration(
                color: glassSecondary,
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: glassBorder),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  const Text(
                    '📜 Riwayat',
                    style: TextStyle(color: softGrey, fontSize: 9),
                  ),
                  Wrap(
                    spacing: 4,
                    children: _history.map((value) {
                      return Text(
                        _diceEmojis[value - 1],
                        style: const TextStyle(fontSize: 14),
                      );
                    }).toList(),
                  ),
                  GestureDetector(
                    onTap: () => setState(() => _history.clear()),
                    child: Text(
                      'Hapus',
                      style: TextStyle(color: Colors.redAccent, fontSize: 9),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

// ============================================================
// GAME 4: PUZZLE
// ============================================================
class PuzzleGame extends StatefulWidget {
  const PuzzleGame({super.key});

  @override
  State<PuzzleGame> createState() => _PuzzleGameState();
}

class _PuzzleGameState extends State<PuzzleGame> {
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF8A99B0);
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);
  LinearGradient get neonGradient => const LinearGradient(
        colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  List<int> _tiles = [];
  int _emptyIndex = 15;
  bool _isSolved = false;
  int _moves = 0;
  int _timer = 0;
  Timer? _timerTimer;
  bool _isTimerRunning = false;
  int _bestTime = 0;
  bool _showHint = false;
  int _hintCount = 0;

  @override
  void initState() {
    super.initState();
    _loadBestTime();
    _resetGame();
  }

  Future<void> _loadBestTime() async {
    final data = await GameSystem.loadData();
    setState(() {
      _bestTime = data['gameStats']['puzzle']['bestTime'] ?? 0;
    });
  }

  void _resetGame() {
    final tiles = List.generate(16, (i) => i);
    tiles.shuffle();
    while (!_isSolvable(tiles)) {
      tiles.shuffle();
    }
    _timerTimer?.cancel();
    setState(() {
      _tiles = tiles;
      _emptyIndex = tiles.indexOf(15);
      _isSolved = false;
      _moves = 0;
      _timer = 0;
      _isTimerRunning = false;
      _showHint = false;
      _hintCount = 0;
    });
  }

  bool _isSolvable(List<int> tiles) {
    int inversions = 0;
    for (int i = 0; i < 16; i++) {
      for (int j = i + 1; j < 16; j++) {
        if (tiles[i] != 15 && tiles[j] != 15 && tiles[i] > tiles[j]) {
          inversions++;
        }
      }
    }
    return inversions % 2 == 0;
  }

  void _startTimer() {
    if (_isTimerRunning) return;
    setState(() => _isTimerRunning = true);
    _timerTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() => _timer++);
    });
  }

  void _moveTile(int index) {
    if (_isSolved) return;
    if (!_isTimerRunning && _moves == 0) _startTimer();
    
    final row = index ~/ 4;
    final col = index % 4;
    final emptyRow = _emptyIndex ~/ 4;
    final emptyCol = _emptyIndex % 4;

    if ((row == emptyRow && (col - emptyCol).abs() == 1) ||
        (col == emptyCol && (row - emptyRow).abs() == 1)) {
      setState(() {
        _tiles[_emptyIndex] = _tiles[index];
        _tiles[index] = 15;
        _emptyIndex = index;
        _moves++;
        _checkSolved();
      });
    }
  }

  void _checkSolved() {
    bool solved = true;
    for (int i = 0; i < 15; i++) {
      if (_tiles[i] != i) {
        solved = false;
        break;
      }
    }
    if (solved) {
      _timerTimer?.cancel();
      setState(() => _isSolved = true);
      if (_bestTime == 0 || _timer < _bestTime) {
        _bestTime = _timer;
        _saveBestTime();
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('🏆 REKOR BARU!', style: TextStyle(color: Colors.white)),
            backgroundColor: Color(0xFF0F1426),
          ),
        );
      }
      GameSystem.addCoins(20);
      GameSystem.addXP(15);
    }
  }

  Future<void> _saveBestTime() async {
    final data = await GameSystem.loadData();
    data['gameStats']['puzzle']['bestTime'] = _bestTime;
    await GameSystem.saveData(data);
  }

  void _showHintTile() {
    if (_isSolved || _hintCount >= 3) return;
    for (int i = 0; i < 15; i++) {
      if (_tiles[i] != i) {
        setState(() => _showHint = true);
        _hintCount++;
        Future.delayed(const Duration(seconds: 2), () {
          setState(() => _showHint = false);
        });
        return;
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Langkah: $_moves',
                style: TextStyle(color: accentNeon, fontSize: 11, fontWeight: FontWeight.bold),
              ),
              Row(
                children: [
                  Icon(Icons.timer, color: accentNeon, size: 14),
                  const SizedBox(width: 4),
                  Text(
                    '${_timer}s',
                    style: TextStyle(color: accentNeon, fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFA500)]),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      '🏆 ${_bestTime}s',
                      style: const TextStyle(color: Colors.black, fontSize: 9, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              if (_isSolved)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: Colors.green.withOpacity(0.2),
                    borderRadius: BorderRadius.circular(6),
                    border: Border.all(color: Colors.green.withOpacity(0.3)),
                  ),
                  child: const Text(
                    '🎉 SELESAI!',
                    style: TextStyle(color: Colors.green, fontSize: 9, fontWeight: FontWeight.bold),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 6),
          Expanded(
            child: GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: 4,
                mainAxisSpacing: 4,
              ),
              itemCount: 16,
              itemBuilder: (context, index) {
                final value = _tiles[index];
                final isHint = _showHint && value != 15 && value != index;
                if (value == 15) {
                  return Container(
                    decoration: BoxDecoration(
                      color: glassSecondary,
                      borderRadius: BorderRadius.circular(8),
                    ),
                  );
                }
                return GestureDetector(
                  onTap: () => _moveTile(index),
                  child: Container(
                    decoration: BoxDecoration(
                      gradient: isHint 
                          ? const LinearGradient(colors: [Colors.yellow, Colors.orange])
                          : neonGradient,
                      borderRadius: BorderRadius.circular(8),
                      boxShadow: isHint ? [
                        BoxShadow(color: Colors.yellow.withOpacity(0.3), blurRadius: 10),
                      ] : [
                        BoxShadow(color: accentNeon.withOpacity(0.2), blurRadius: 6),
                      ],
                    ),
                    child: Center(
                      child: Text(
                        '${value + 1}',
                        style: TextStyle(
                          color: isHint ? Colors.black : primaryWhite,
                          fontSize: 18,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Expanded(
                child: Container(
                  height: 36,
                  decoration: BoxDecoration(
                    gradient: neonGradient,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: ElevatedButton(
                    onPressed: _resetGame,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: Colors.transparent,
                      shadowColor: Colors.transparent,
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(10),
                      ),
                    ),
                    child: const Text(
                      'ACAK ULANG',
                      style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 11),
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 6),
              Container(
                height: 36,
                width: 36,
                decoration: BoxDecoration(
                  color: glassSecondary,
                  borderRadius: BorderRadius.circular(10),
                  border: Border.all(color: glassBorder),
                ),
                child: IconButton(
                  icon: Icon(Icons.lightbulb, color: _hintCount >= 3 ? softGrey : accentNeon, size: 18),
                  onPressed: _hintCount < 3 ? _showHintTile : null,
                  tooltip: 'Hint (${3 - _hintCount} tersisa)',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timerTimer?.cancel();
    super.dispose();
  }
}

// ============================================================
// GAME 5: TEBAK WARNA
// ============================================================
class TebakWarnaGame extends StatefulWidget {
  const TebakWarnaGame({super.key});

  @override
  State<TebakWarnaGame> createState() => _TebakWarnaGameState();
}

class _TebakWarnaGameState extends State<TebakWarnaGame> {
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);
  LinearGradient get neonGradient => const LinearGradient(
        colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  final Random _random = Random();
  List<Color> _colors = [];
  Color _targetColor = Colors.red;
  int _score = 0;
  int _total = 0;
  bool _isAnswered = false;
  int _combo = 0;
  int _maxCombo = 0;
  int _timer = 5;
  Timer? _timerTimer;
  bool _isTimerRunning = false;
  bool _fastMode = false;
  int _highScore = 0;

  final List<Map<String, dynamic>> _allColors = [
    {'color': Colors.red, 'name': 'Merah'},
    {'color': Colors.blue, 'name': 'Biru'},
    {'color': Colors.green, 'name': 'Hijau'},
    {'color': Colors.yellow, 'name': 'Kuning'},
    {'color': Colors.purple, 'name': 'Ungu'},
    {'color': Colors.orange, 'name': 'Orange'},
    {'color': Colors.pink, 'name': 'Pink'},
    {'color': Colors.teal, 'name': 'Teal'},
    {'color': Colors.indigo, 'name': 'Indigo'},
    {'color': Colors.brown, 'name': 'Coklat'},
    {'color': Colors.cyan, 'name': 'Cyan'},
    {'color': Colors.lime, 'name': 'Lime'},
  ];

  @override
  void initState() {
    super.initState();
    _loadHighScore();
    _resetGame();
  }

  Future<void> _loadHighScore() async {
    final data = await GameSystem.loadData();
    setState(() {
      _highScore = data['gameStats']['tebakWarna']['highScore'] ?? 0;
    });
  }

  void _resetGame() {
    _timerTimer?.cancel();
    setState(() {
      _colors = _allColors.map((e) => e['color'] as Color).toList();
      _score = 0;
      _total = 0;
      _isAnswered = false;
      _combo = 0;
      _maxCombo = 0;
      _timer = 5;
      _isTimerRunning = false;
      _fastMode = false;
    });
    _nextRound();
  }

  void _nextRound() {
    _timerTimer?.cancel();
    setState(() {
      _targetColor = _colors[_random.nextInt(_colors.length)];
      _isAnswered = false;
      _timer = _fastMode ? 3 : 5;
      _isTimerRunning = true;
    });
    _startTimer();
  }

  void _startTimer() {
    _timerTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        _timer--;
        if (_timer <= 0) {
          timer.cancel();
          _isTimerRunning = false;
          if (!_isAnswered) {
            _combo = 0;
            _total++;
            if (_total < 10) {
              Future.delayed(const Duration(milliseconds: 500), _nextRound);
            } else {
              _endGame();
            }
          }
        }
      });
    });
  }

  void _guessColor(Color selectedColor) {
    if (_isAnswered) return;
    _timerTimer?.cancel();
    setState(() {
      _isAnswered = true;
      _isTimerRunning = false;
      _total++;
      if (selectedColor == _targetColor) {
        _score++;
        _combo++;
        if (_combo > _maxCombo) _maxCombo = _combo;
        int bonus = _combo > 1 ? _combo * 2 : 0;
        GameSystem.addCoins(5 + bonus);
        GameSystem.addXP(5 + _combo);
      } else {
        _combo = 0;
      }
    });
    if (_total < 10) {
      Future.delayed(const Duration(seconds: 1), _nextRound);
    } else {
      _endGame();
    }
  }

  void _endGame() {
    if (_score > _highScore) {
      _highScore = _score;
      _saveHighScore();
    }
  }

  Future<void> _saveHighScore() async {
    final data = await GameSystem.loadData();
    data['gameStats']['tebakWarna']['highScore'] = _highScore;
    await GameSystem.saveData(data);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Skor: $_score/$_total',
                style: TextStyle(color: accentNeon, fontSize: 11, fontWeight: FontWeight.bold),
              ),
              Row(
                children: [
                  if (_combo > 1)
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                      decoration: BoxDecoration(
                        color: Colors.orange.withOpacity(0.2),
                        borderRadius: BorderRadius.circular(4),
                        border: Border.all(color: Colors.orange.withOpacity(0.3)),
                      ),
                      child: Text(
                        '🔥 x$_combo',
                        style: const TextStyle(color: Colors.orange, fontSize: 10, fontWeight: FontWeight.bold),
                      ),
                    ),
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFA500)]),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      '🏆 $_highScore',
                      style: const TextStyle(color: Colors.black, fontSize: 9, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(width: 6),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      color: _timer < 3 ? Colors.red.withOpacity(0.2) : accentNeon.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(4),
                      border: Border.all(
                        color: _timer < 3 ? Colors.red.withOpacity(0.3) : accentNeon.withOpacity(0.2),
                      ),
                    ),
                    child: Row(
                      children: [
                        Icon(Icons.timer, color: _timer < 3 ? Colors.red : accentNeon, size: 12),
                        const SizedBox(width: 2),
                        Text(
                          '${_timer}s',
                          style: TextStyle(
                            color: _timer < 3 ? Colors.red : accentNeon,
                            fontSize: 10,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ],
          ),
          const SizedBox(height: 6),
          Expanded(
            child: Center(
              child: Container(
                width: double.infinity,
                height: 120,
                decoration: BoxDecoration(
                  color: _targetColor,
                  borderRadius: BorderRadius.circular(14),
                  boxShadow: [
                    BoxShadow(
                      color: _targetColor.withOpacity(0.3),
                      blurRadius: 25,
                    ),
                  ],
                ),
                child: Center(
                  child: Text(
                    _isAnswered ? 
                      (_allColors.firstWhere((e) => e['color'] == _targetColor)['name'] as String) : 
                      '???',
                    style: TextStyle(
                      color: _targetColor.computeLuminance() > 0.5 ? Colors.black : Colors.white,
                      fontSize: 22,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(height: 6),
          if (_total < 10)
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: _colors.map((color) {
                final name = _allColors.firstWhere((e) => e['color'] == color)['name'] as String;
                final isCorrect = color == _targetColor;
                return GestureDetector(
                  onTap: () => _guessColor(color),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: _isAnswered ? (isCorrect ? Colors.green : color) : color,
                      borderRadius: BorderRadius.circular(16),
                      border: Border.all(
                        color: _isAnswered ? (isCorrect ? Colors.green : Colors.red) : primaryWhite.withOpacity(0.2),
                        width: _isAnswered ? 2 : 1,
                      ),
                      boxShadow: [
                        BoxShadow(
                          color: color.withOpacity(0.3),
                          blurRadius: 6,
                        ),
                      ],
                    ),
                    child: Text(
                      name,
                      style: TextStyle(
                        color: color.computeLuminance() > 0.5 ? Colors.black : Colors.white,
                        fontWeight: FontWeight.bold,
                        fontSize: 11,
                      ),
                    ),
                  ),
                );
              }).toList(),
            ),
          if (_total >= 10) ...[
            const SizedBox(height: 6),
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: glassSecondary,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: glassBorder),
              ),
              child: Column(
                children: [
                  Text(
                    '🎉 Selesai!',
                    style: TextStyle(
                      color: Colors.green,
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  Text(
                    'Benar: ${(_score / _total * 100).toStringAsFixed(0)}%',
                    style: TextStyle(color: primaryWhite, fontSize: 13),
                  ),
                  if (_maxCombo > 1)
                    Text(
                      '🔥 Combo Terbaik: $_maxCombo',
                      style: const TextStyle(color: Colors.orange, fontSize: 12, fontWeight: FontWeight.bold),
                    ),
                  const SizedBox(height: 6),
                  Container(
                    height: 32,
                    decoration: BoxDecoration(
                      gradient: neonGradient,
                      borderRadius: BorderRadius.circular(10),
                    ),
                    child: ElevatedButton(
                      onPressed: () {
                        setState(() => _fastMode = !_fastMode);
                        _resetGame();
                      },
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.transparent,
                        shadowColor: Colors.transparent,
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(10),
                        ),
                      ),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Icon(_fastMode ? Icons.speed : Icons.speed, color: primaryWhite, size: 14),
                          const SizedBox(width: 4),
                          Text(
                            _fastMode ? '⚡ MODE CEPAT' : 'MAIN LAGI',
                            style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 11),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timerTimer?.cancel();
    super.dispose();
  }
}

// ============================================================
// GAME 6: MEMORY CARD
// ============================================================
class MemoryCardGame extends StatefulWidget {
  const MemoryCardGame({super.key});

  @override
  State<MemoryCardGame> createState() => _MemoryCardGameState();
}

class _MemoryCardGameState extends State<MemoryCardGame> with SingleTickerProviderStateMixin {
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF8A99B0);
  Color get glassPrimary => const Color(0x1AFFFFFF);
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);
  LinearGradient get neonGradient => const LinearGradient(
        colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  List<int> _cards = [];
  List<bool> _flipped = [];
  List<bool> _matched = [];
  int _selectedIndex = -1;
  int _pairs = 0;
  int _moves = 0;
  bool _isProcessing = false;
  int _timer = 0;
  Timer? _timerTimer;
  bool _isTimerRunning = false;
  int _stars = 0;
  int _bestScore = 0;

  final List<String> _emojiPairs = ['🍎', '🍕', '🚀', '🎮', '🌈', '🎯', '🐱', '🐶'];

  @override
  void initState() {
    super.initState();
    _loadBestScore();
    _resetGame();
  }

  Future<void> _loadBestScore() async {
    final data = await GameSystem.loadData();
    setState(() {
      _bestScore = data['gameStats']['memoryCard']['bestScore'] ?? 0;
    });
  }

  void _resetGame() {
    final deck = [..._emojiPairs, ..._emojiPairs];
    deck.shuffle();
    _timerTimer?.cancel();
    setState(() {
      _cards = deck.map((e) => _emojiPairs.indexOf(e)).toList();
      _flipped = List<bool>.filled(_emojiPairs.length * 2, false);
      _matched = List<bool>.filled(_emojiPairs.length * 2, false);
      _selectedIndex = -1;
      _pairs = 0;
      _moves = 0;
      _isProcessing = false;
      _timer = 0;
      _isTimerRunning = false;
      _stars = 0;
    });
  }

  void _startTimer() {
    if (_isTimerRunning) return;
    setState(() => _isTimerRunning = true);
    _timerTimer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() => _timer++);
    });
  }

  void _selectCard(int index) {
    if (_isProcessing) return;
    if (_flipped[index] || _matched[index]) return;
    if (!_isTimerRunning) _startTimer();

    setState(() {
      _flipped[index] = true;
      _moves++;
    });

    if (_selectedIndex == -1) {
      _selectedIndex = index;
    } else {
      _isProcessing = true;
      _checkMatch(_selectedIndex, index);
      _selectedIndex = -1;
    }
  }

  void _checkMatch(int index1, int index2) {
    if (_cards[index1] == _cards[index2]) {
      setState(() {
        _matched[index1] = true;
        _matched[index2] = true;
        _pairs++;
        _isProcessing = false;
        if (_pairs == _emojiPairs.length) {
          _endGame();
        }
      });
    } else {
      Future.delayed(const Duration(milliseconds: 800), () {
        setState(() {
          _flipped[index1] = false;
          _flipped[index2] = false;
          _isProcessing = false;
        });
      });
    }
  }

  void _endGame() {
    _timerTimer?.cancel();
    _isTimerRunning = false;
    
    if (_moves <= 8) _stars = 3;
    else if (_moves <= 12) _stars = 2;
    else if (_moves <= 16) _stars = 1;
    else _stars = 0;
    
    int score = max(0, 100 - (_moves * 2) + (_timer * 0));
    if (score > _bestScore) {
      _bestScore = score;
      _saveBestScore();
    }
    
    GameSystem.addCoins(15 + _stars * 5);
    GameSystem.addXP(10 + _stars * 3);
  }

  Future<void> _saveBestScore() async {
    final data = await GameSystem.loadData();
    data['gameStats']['memoryCard']['bestScore'] = _bestScore;
    await GameSystem.saveData(data);
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Column(
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Pasangan: $_pairs/${_emojiPairs.length}',
                style: TextStyle(color: accentNeon, fontSize: 11, fontWeight: FontWeight.bold),
              ),
              Row(
                children: [
                  Icon(Icons.timer, color: accentNeon, size: 14),
                  const SizedBox(width: 4),
                  Text(
                    '${_timer}s',
                    style: TextStyle(color: accentNeon, fontSize: 11, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(width: 10),
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
                    decoration: BoxDecoration(
                      gradient: const LinearGradient(colors: [Color(0xFFFFD700), Color(0xFFFFA500)]),
                      borderRadius: BorderRadius.circular(4),
                    ),
                    child: Text(
                      '🏆 $_bestScore',
                      style: const TextStyle(color: Colors.black, fontSize: 9, fontWeight: FontWeight.bold),
                    ),
                  ),
                ],
              ),
              Text(
                'Langkah: $_moves',
                style: TextStyle(color: softGrey, fontSize: 11),
              ),
            ],
          ),
          const SizedBox(height: 6),
          if (_pairs == _emojiPairs.length) ...[
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(3, (i) {
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: Icon(
                    i < _stars ? Icons.star : Icons.star_border,
                    color: i < _stars ? Colors.amber : softGrey,
                    size: 24,
                  ),
                );
              }),
            ),
            const SizedBox(height: 6),
          ],
          Expanded(
            child: GridView.builder(
              physics: const NeverScrollableScrollPhysics(),
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                crossAxisSpacing: 6,
                mainAxisSpacing: 6,
              ),
              itemCount: _emojiPairs.length * 2,
              itemBuilder: (context, index) {
                final isFlipped = _flipped[index] || _matched[index];
                final isMatched = _matched[index];
                return GestureDetector(
                  onTap: () => _selectCard(index),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    curve: Curves.easeInOut,
                    decoration: BoxDecoration(
                      gradient: isFlipped
                          ? (isMatched
                              ? const LinearGradient(colors: [Colors.green, Colors.greenAccent])
                              : neonGradient)
                          : LinearGradient(
                              colors: [glassPrimary, glassSecondary],
                              begin: Alignment.topLeft,
                              end: Alignment.bottomRight,
                            ),
                      borderRadius: BorderRadius.circular(12),
                      border: Border.all(
                        color: isFlipped ? accentNeon.withOpacity(0.3) : glassBorder,
                        width: 1,
                      ),
                      boxShadow: isFlipped
                          ? [BoxShadow(color: accentNeon.withOpacity(0.2), blurRadius: 10)]
                          : [],
                    ),
                    child: Center(
                      child: isFlipped
                          ? Text(
                              _emojiPairs[_cards[index]],
                              style: const TextStyle(fontSize: 28),
                            )
                          : Icon(
                              Icons.question_mark,
                              color: softGrey.withOpacity(0.5),
                              size: 22,
                            ),
                    ),
                  ),
                );
              },
            ),
          ),
          const SizedBox(height: 6),
          Container(
            height: 36,
            decoration: BoxDecoration(
              gradient: neonGradient,
              borderRadius: BorderRadius.circular(10),
            ),
            child: ElevatedButton(
              onPressed: _resetGame,
              style: ElevatedButton.styleFrom(
                backgroundColor: Colors.transparent,
                shadowColor: Colors.transparent,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10),
                ),
              ),
              child: const Text(
                'RESET',
                style: TextStyle(color: primaryWhite, fontWeight: FontWeight.bold, fontSize: 11),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    _timerTimer?.cancel();
    super.dispose();
  }
}