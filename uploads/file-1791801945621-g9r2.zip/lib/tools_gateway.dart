// tools_page.dart
import 'package:flutter/material.dart';
import 'manage_server.dart';
import 'wifi_internal.dart';
import 'wifi_external.dart';
import 'ddos_panel.dart';
import 'nik_check.dart';
import 'tiktok_page.dart';
import 'instagram_page.dart';
import 'qr_gen.dart';
import 'domain_page.dart';
import 'spam_ngl.dart';
import 'shortlink_page.dart';
import 'ip_scanner_page.dart';
import 'phone_lookup_page.dart';
import 'spotify_music.dart';
import 'anime.dart';
import 'comic.dart';
import 'edukasi_page.dart';

class ToolsPage extends StatelessWidget {
  final String sessionKey;
  final String userRole;
  final List<Map<String, dynamic>> listDoos;

  const ToolsPage({
    super.key,
    required this.sessionKey,
    required this.userRole,
    required this.listDoos,
  });

  // === TEMA NEON FUTURISTIK ===
  static const Color bgPrimary = Color(0xFF0A0E1A);
  static const Color bgSecondary = Color(0xFF111828);
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color accentPurple = Color(0xFF9C27B0);
  static const Color accentPink = Color(0xFFEC4899);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF94A3B8);

  Color get glassPrimary => const Color(0x1AFFFFFF);
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);

  LinearGradient get neonGradient => const LinearGradient(
        colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
      );

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgPrimary,
      body: Container(
        decoration: BoxDecoration(
          gradient: RadialGradient(
            center: Alignment.topLeft,
            radius: 1.5,
            colors: [
              accentNeon.withOpacity(0.05),
              bgPrimary,
              bgPrimary,
            ],
            stops: const [0.0, 0.4, 1.0],
          ),
        ),
        child: CustomPaint(
          painter: _NeonGridPainter(),
          child: SafeArea(
            child: Column(
              children: [
                // === GLASS HEADER ===
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 32),
                  child: Column(
                    children: [
                      TweenAnimationBuilder(
                        tween: Tween<double>(begin: 0.8, end: 1.0),
                        duration: const Duration(milliseconds: 800),
                        curve: Curves.easeOutBack,
                        builder: (context, double scale, child) {
                          return Transform.scale(
                            scale: scale,
                            child: Container(
                              width: 80,
                              height: 80,
                              decoration: BoxDecoration(
                                gradient: neonGradient,
                                shape: BoxShape.circle,
                                boxShadow: [
                                  BoxShadow(
                                    color: accentNeon.withOpacity(0.4),
                                    blurRadius: 30,
                                    spreadRadius: 10,
                                  ),
                                  BoxShadow(
                                    color: accentPurple.withOpacity(0.2),
                                    blurRadius: 50,
                                    spreadRadius: 20,
                                  ),
                                ],
                              ),
                              child: const Center(
                                child: Icon(
                                  Icons.build_circle_outlined,
                                  color: primaryWhite,
                                  size: 42,
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 20),
                      ShaderMask(
                        shaderCallback: (bounds) => neonGradient.createShader(bounds),
                        child: const Text(
                          "✦ Tools Dashboard",
                          style: TextStyle(
                            color: primaryWhite,
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            letterSpacing: 2,
                          ),
                        ),
                      ),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6),
                        decoration: BoxDecoration(
                          gradient: LinearGradient(
                            colors: [glassPrimary, glassSecondary],
                          ),
                          borderRadius: BorderRadius.circular(20),
                          border: Border.all(color: glassBorder),
                        ),
                        child: Text(
                          "✦ Advanced Security & OSINT Tools ✦",
                          style: TextStyle(
                            color: accentNeon,
                            fontSize: 11,
                            letterSpacing: 1,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 8),

                // === GLASS CATEGORY CARDS (GRID 2 KOLOM) ===
                Expanded(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: GridView.count(
                      crossAxisCount: 2,
                      crossAxisSpacing: 14,
                      mainAxisSpacing: 14,
                      childAspectRatio: 1.0,
                      children: [
                        _buildNeonToolCard(
                          icon: Icons.flash_on_rounded,
                          title: "DDoS Tools",
                          subtitle: "Attack Panel",
                          gradient: neonGradient,
                          onTap: () => _showDDoSTools(context),
                        ),
                        _buildNeonToolCard(
                          icon: Icons.wifi_rounded,
                          title: "Network",
                          subtitle: "WiFi & Spam",
                          gradient: neonGradient,
                          onTap: () => _showNetworkTools(context),
                        ),
                        _buildNeonToolCard(
                          icon: Icons.search_rounded,
                          title: "OSINT",
                          subtitle: "Investigation",
                          gradient: neonGradient,
                          onTap: () => _showOSINTTools(context),
                        ),
                        _buildNeonToolCard(
                          icon: Icons.download_rounded,
                          title: "Downloader",
                          subtitle: "Social Media",
                          gradient: neonGradient,
                          onTap: () => _showDownloaderTools(context),
                        ),
                        _buildNeonToolCard(
                          icon: Icons.build_rounded,
                          title: "Utilities",
                          subtitle: "Extra Tools",
                          gradient: neonGradient,
                          onTap: () => _showUtilityTools(context),
                        ),
                        _buildNeonToolCard(
                          icon: Icons.music_note_rounded,
                          title: "Music",
                          subtitle: "Spotify Player",
                          gradient: neonGradient,
                          onTap: () => _showMusicTools(context),
                        ),
                        _buildNeonToolCard(
                          icon: Icons.movie_rounded,
                          title: "Anime",
                          subtitle: "Nonton Anime",
                          gradient: neonGradient,
                          onTap: () => _showAnimeTools(context),
                        ),
                        _buildNeonToolCard(
                          icon: Icons.book_rounded,
                          title: "Comic",
                          subtitle: "Baca Manga",
                          gradient: neonGradient,
                          onTap: () => _showComicTools(context),
                        ),
                        _buildNeonToolCard(
                          icon: Icons.school_rounded,
                          title: "Edukasi",
                          subtitle: "Belajar & Baca",
                          gradient: neonGradient,
                          onTap: () => _showEdukasiTools(context),
                        ),
                        _buildNeonToolCard(
                          icon: Icons.radar_rounded,
                          title: "RAT",
                          subtitle: "Coming Soon",
                          gradient: neonGradient,
                          onTap: () => _showComingSoon(context),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ===== NEON TOOL CARD =====
  Widget _buildNeonToolCard({
    required IconData icon,
    required String title,
    required String subtitle,
    required LinearGradient gradient,
    required VoidCallback onTap,
  }) {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 500),
      curve: Curves.easeOutCubic,
      builder: (context, double scale, child) {
        return Transform.scale(scale: scale, child: child);
      },
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [glassPrimary, glassSecondary],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(20),
            border: Border.all(
              color: accentNeon.withOpacity(0.15),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: accentNeon.withOpacity(0.05),
                blurRadius: 20,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.end,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Spacer(),
                Container(
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    gradient: gradient,
                    borderRadius: BorderRadius.circular(14),
                    boxShadow: [
                      BoxShadow(
                        color: gradient.colors.first.withOpacity(0.3),
                        blurRadius: 12,
                      ),
                    ],
                  ),
                  child: Icon(icon, color: primaryWhite, size: 26),
                ),
                const SizedBox(height: 12),
                Text(
                  title,
                  style: const TextStyle(
                    color: primaryWhite,
                    fontSize: 15,
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0.5,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: softGrey.withOpacity(0.8),
                    fontSize: 11,
                    letterSpacing: 0.3,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  // ===== NEON BOTTOM SHEET =====
  void _showNeonBottomSheet(BuildContext context, String title, IconData icon, List<Widget> children) {
    showModalBottomSheet(
      context: context,
      backgroundColor: Colors.transparent,
      isScrollControlled: true,
      builder: (context) => Container(
        height: MediaQuery.of(context).size.height * 0.7,
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [bgPrimary, bgSecondary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: const BorderRadius.only(
            topLeft: Radius.circular(28),
            topRight: Radius.circular(28),
          ),
          border: Border.all(color: glassBorder),
        ),
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                gradient: LinearGradient(
                  colors: [glassPrimary, glassSecondary],
                ),
                borderRadius: const BorderRadius.only(
                  topLeft: Radius.circular(28),
                  topRight: Radius.circular(28),
                ),
              ),
              child: Row(
                children: [
                  Container(
                    padding: const EdgeInsets.all(10),
                    decoration: BoxDecoration(
                      gradient: neonGradient,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: accentNeon.withOpacity(0.3),
                          blurRadius: 10,
                        ),
                      ],
                    ),
                    child: Icon(icon, color: primaryWhite, size: 24),
                  ),
                  const SizedBox(width: 14),
                  Text(
                    title,
                    style: const TextStyle(
                      color: primaryWhite,
                      fontSize: 20,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: SingleChildScrollView(
                  physics: const BouncingScrollPhysics(),
                  child: Column(
                    children: children,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  // ===== TOOL OPTION =====
  Widget _buildNeonToolOption({
    required IconData icon,
    required String label,
    required String description,
    required Color color,
    required VoidCallback onTap,
  }) {
    return TweenAnimationBuilder(
      tween: Tween<double>(begin: 0, end: 1),
      duration: const Duration(milliseconds: 400),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [glassPrimary, glassSecondary],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: glassBorder),
        ),
        child: ListTile(
          leading: Container(
            padding: const EdgeInsets.all(10),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [color, color.withOpacity(0.7)],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(12),
              boxShadow: [
                BoxShadow(
                  color: color.withOpacity(0.3),
                  blurRadius: 8,
                ),
              ],
            ),
            child: Icon(icon, color: primaryWhite, size: 20),
          ),
          title: Text(
            label,
            style: const TextStyle(
              color: primaryWhite,
              fontSize: 15,
              fontWeight: FontWeight.w600,
            ),
          ),
          subtitle: Text(
            description,
            style: TextStyle(
              color: softGrey,
              fontSize: 12,
            ),
          ),
          trailing: Container(
            padding: const EdgeInsets.all(6),
            decoration: BoxDecoration(
              color: color.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
              border: Border.all(color: color.withOpacity(0.2)),
            ),
            child: Icon(Icons.arrow_forward_ios_rounded, color: color, size: 14),
          ),
          onTap: onTap,
        ),
      ),
    );
  }

  // ===== CONTENT FUNCTIONS =====
  void _showDDoSTools(BuildContext context) {
    _showNeonBottomSheet(
      context,
      "DDoS Tools",
      Icons.flash_on_rounded,
      [
        _buildNeonToolOption(
          icon: Icons.flash_on_rounded,
          label: "Attack Panel",
          description: "Launch DDoS attacks with power",
          color: accentNeon,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => AttackPanel(
                  sessionKey: sessionKey,
                  listDoos: listDoos,
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 12),
        _buildNeonToolOption(
          icon: Icons.dns_rounded,
          label: "Manage Server",
          description: "Configure server settings",
          color: accentPurple,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ManageServerPage(keyToken: sessionKey),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showNetworkTools(BuildContext context) {
    List<Widget> options = [
      _buildNeonToolOption(
        icon: Icons.message_rounded,
        label: "Spam NGL",
        description: "Anonymous message spam",
        color: accentNeon,
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const NglPage()),
          );
        },
      ),
      const SizedBox(height: 12),
      _buildNeonToolOption(
        icon: Icons.wifi_off_rounded,
        label: "WiFi Killer (Internal)",
        description: "Internal network attacks",
        color: accentPurple,
        onTap: () {
          Navigator.pop(context);
          Navigator.push(
            context,
            MaterialPageRoute(builder: (context) => const WifiKillerPage()),
          );
        },
      ),
    ];

    if (userRole == "vip" || userRole == "owner" || userRole == "reseller") {
      options.addAll([
        const SizedBox(height: 12),
        _buildNeonToolOption(
          icon: Icons.router_rounded,
          label: "WiFi Killer (External)",
          description: "External network attacks",
          color: accentPink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => WifiInternalPage(sessionKey: sessionKey),
              ),
            );
          },
        ),
      ]);
    }

    _showNeonBottomSheet(context, "Network Tools", Icons.wifi_rounded, options);
  }

  void _showOSINTTools(BuildContext context) {
    _showNeonBottomSheet(
      context,
      "OSINT Tools",
      Icons.search_rounded,
      [
        _buildNeonToolOption(
          icon: Icons.badge_rounded,
          label: "NIK Detail",
          description: "Indonesian ID card lookup",
          color: accentNeon,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const NikCheckerPage()),
            );
          },
        ),
        const SizedBox(height: 12),
        _buildNeonToolOption(
          icon: Icons.domain_rounded,
          label: "Domain OSINT",
          description: "Domain information gathering",
          color: accentPurple,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const DomainOsintPage()),
            );
          },
        ),
        const SizedBox(height: 12),
        _buildNeonToolOption(
          icon: Icons.phone_android_rounded,
          label: "Phone Lookup",
          description: "Cek informasi nomor telepon",
          color: accentPink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => PhoneLookupPage(
                  sessionKey: sessionKey,
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showDownloaderTools(BuildContext context) {
    _showNeonBottomSheet(
      context,
      "Media Downloader",
      Icons.download_rounded,
      [
        _buildNeonToolOption(
          icon: Icons.video_library_rounded,
          label: "TikTok Downloader",
          description: "Download TikTok videos without watermark",
          color: accentNeon,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const TiktokDownloaderPage()),
            );
          },
        ),
        const SizedBox(height: 12),
        _buildNeonToolOption(
          icon: Icons.camera_alt_rounded,
          label: "Instagram Downloader",
          description: "Download Instagram content",
          color: accentPurple,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const InstagramDownloaderPage()),
            );
          },
        ),
      ],
    );
  }

  void _showUtilityTools(BuildContext context) {
    _showNeonBottomSheet(
      context,
      "Utility Tools",
      Icons.build_rounded,
      [
        _buildNeonToolOption(
          icon: Icons.qr_code_rounded,
          label: "QR Generator",
          description: "Generate QR codes instantly",
          color: accentNeon,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => const QrGeneratorPage()),
            );
          },
        ),
        const SizedBox(height: 12),
        _buildNeonToolOption(
          icon: Icons.link_rounded,
          label: "Shortlink URL",
          description: "Pendekkan URL panjangmu",
          color: accentPurple,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => ShortlinkPage(
                  sessionKey: sessionKey,
                ),
              ),
            );
          },
        ),
        const SizedBox(height: 12),
        _buildNeonToolOption(
          icon: Icons.dns_rounded,
          label: "IP Scanner",
          description: "Cek informasi alamat IP",
          color: accentPink,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => IpScannerPage(
                  sessionKey: sessionKey,
                ),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showMusicTools(BuildContext context) {
    _showNeonBottomSheet(
      context,
      "Music Player",
      Icons.music_note_rounded,
      [
        _buildNeonToolOption(
          icon: Icons.music_note_rounded,
          label: "Spotify Music",
          description: "Dengerin musik keren",
          color: accentNeon,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const SpotifyMusicPage(),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showAnimeTools(BuildContext context) {
    _showNeonBottomSheet(
      context,
      "Anime",
      Icons.movie_rounded,
      [
        _buildNeonToolOption(
          icon: Icons.tv_rounded,
          label: "Anime",
          description: "Nonton anime terbaru",
          color: accentNeon,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const HomeAnimePage(),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showComicTools(BuildContext context) {
    _showNeonBottomSheet(
      context,
      "Comic Zone",
      Icons.book_rounded,
      [
        _buildNeonToolOption(
          icon: Icons.book_rounded,
          label: "Comic Reader",
          description: "Baca manga & komik terbaru",
          color: accentNeon,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const ComicPage(),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showEdukasiTools(BuildContext context) {
    _showNeonBottomSheet(
      context,
      "📚 Edukasi",
      Icons.school_rounded,
      [
        _buildNeonToolOption(
          icon: Icons.school_rounded,
          label: "Belajar Online",
          description: "Akses website edukasi",
          color: accentNeon,
          onTap: () {
            Navigator.pop(context);
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => const EdukasiPage(),
              ),
            );
          },
        ),
      ],
    );
  }

  void _showComingSoon(BuildContext context) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Row(
          children: [
            Container(
              padding: const EdgeInsets.all(4),
              decoration: BoxDecoration(
                gradient: neonGradient,
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(Icons.hourglass_top_rounded, color: primaryWhite, size: 16),
            ),
            const SizedBox(width: 10),
            const Text(
              '⏳ RAT Coming Soon!',
              style: TextStyle(
                color: primaryWhite,
                fontSize: 13,
                fontWeight: FontWeight.w600,
              ),
            ),
          ],
        ),
        backgroundColor: glassPrimary,
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
          side: BorderSide(color: glassBorder),
        ),
        duration: const Duration(seconds: 2),
      ),
    );
  }
}

// ===================== NEON GRID PAINTER =====================
class _NeonGridPainter extends CustomPainter {
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color accentPurple = Color(0xFF9C27B0);
  static const double gridSize = 30.0;

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.02)
      ..strokeWidth = 0.5
      ..style = PaintingStyle.stroke;

    for (double x = 0; x <= size.width; x += gridSize) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), paint);
    }

    for (double y = 0; y <= size.height; y += gridSize) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), paint);
    }

    final neonPaint = Paint()
      ..color = accentNeon.withOpacity(0.05)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    final purplePaint = Paint()
      ..color = accentPurple.withOpacity(0.03)
      ..strokeWidth = 1.5
      ..style = PaintingStyle.stroke;

    for (double x = 0; x <= size.width; x += gridSize * 5) {
      canvas.drawLine(Offset(x, 0), Offset(x, size.height), neonPaint);
    }

    for (double y = 0; y <= size.height; y += gridSize * 5) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y), purplePaint);
    }

    final dotPaint = Paint()
      ..color = accentNeon.withOpacity(0.08)
      ..style = PaintingStyle.fill;

    for (double x = 0; x <= size.width; x += gridSize) {
      for (double y = 0; y <= size.height; y += gridSize) {
        canvas.drawCircle(Offset(x, y), 1.5, dotPaint);
      }
    }

    final diagPaint = Paint()
      ..color = accentNeon.withOpacity(0.015)
      ..strokeWidth = 1
      ..style = PaintingStyle.stroke;

    for (double i = -size.height; i < size.width + size.height; i += 60) {
      canvas.drawLine(
        Offset(i, 0),
        Offset(i + size.height, size.height),
        diagPaint,
      );
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}