// edukasi_page.dart
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class EdukasiPage extends StatefulWidget {
  const EdukasiPage({super.key});

  @override
  State<EdukasiPage> createState() => _EdukasiPageState();
}

class _EdukasiPageState extends State<EdukasiPage> {
  String _currentQuote = '';
  int _selectedCategory = 0;

  // === TEMA NEON ===
  static const Color bgPrimary = Color(0xFF0A0E1A);
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color accentPurple = Color(0xFF9C27B0);
  static const Color primaryWhite = Color(0xFFFFFFFF);
  static const Color softGrey = Color(0xFF94A3B8);
  
  Color get glassPrimary => const Color(0x1AFFFFFF);
  Color get glassSecondary => const Color(0x0DFFFFFF);
  Color get glassBorder => const Color(0x33FFFFFF);
  
  LinearGradient get neonGradient => const LinearGradient(
    colors: [Color(0xFF00F0FF), Color(0xFF9C27B0)],
    begin: Alignment.topLeft,
    end: Alignment.bottomRight,
  );

  // ===== DATA KATEGORI =====
  final List<Map<String, dynamic>> _categories = [
    {
      'name': '📚 Pendidikan Umum',
      'icon': Icons.school_rounded,
      'items': [
        {'name': 'Rumah Belajar', 'url': 'https://belajar.kemdikbud.go.id'},
        {'name': 'Rumah Pendidikan', 'url': 'https://rumahpendidikan.kemdikbud.go.id'},
        {'name': 'Zenius', 'url': 'https://zenius.net'},
        {'name': 'Ruangguru', 'url': 'https://ruangguru.com'},
        {'name': 'Quipper', 'url': 'https://quipper.com'},
      ]
    },
    {
      'name': '💻 Digital & AI',
      'icon': Icons.computer_rounded,
      'items': [
        {'name': 'Bijak Cerdas Berdigital', 'url': 'https://bijakcerdas.dicoding.com'},
        {'name': 'Dicoding', 'url': 'https://dicoding.com'},
        {'name': 'W3Schools', 'url': 'https://w3schools.com'},
        {'name': 'Codecademy', 'url': 'https://codecademy.com'},
        {'name': 'Khan Academy', 'url': 'https://khanacademy.org'},
      ]
    },
    {
      'name': '📖 Kamus & Bahasa',
      'icon': Icons.abc_rounded,
      'items': [
        {'name': 'KBBI Daring', 'url': 'https://kbbi.kemdikbud.go.id'},
        {'name': 'Google Translate', 'url': 'https://translate.google.com'},
        {'name': 'Duolingo', 'url': 'https://duolingo.com'},
      ]
    },
    {
      'name': '🧮 Sains & Matematika',
      'icon': Icons.calculate_rounded,
      'items': [
        {'name': 'Rumus Matematika', 'url': 'https://rumus.co.id'},
        {'name': 'Lab Maya', 'url': 'https://belajar.kemdikbud.go.id'},
        {'name': 'NASA', 'url': 'https://nasa.gov'},
      ]
    },
    {
      'name': '📰 Pengetahuan Umum',
      'icon': Icons.lightbulb_rounded,
      'items': [
        {'name': 'Wikipedia', 'url': 'https://id.wikipedia.org'},
        {'name': 'Peta Budaya', 'url': 'https://petabudaya.belajar.kemdikbud.go.id'},
      ]
    },
  ];

  // ===== DATA KATA MOTIVASI =====
  final List<String> _motivasiQuotes = [
    'Pendidikan adalah senjata paling ampuh yang dapat kamu gunakan untuk mengubah dunia - Nelson Mandela',
    'Hiduplah seolah-olah kamu akan mati besok, belajarlah seolah-olah kamu akan hidup selamanya - Mahatma Gandhi',
    'Belajar adalah satu-satunya hal yang tidak pernah membuat pikiran lelah - Leonardo da Vinci',
    'Tujuan pendidikan itu untuk mempertajam kecerdasan, memperkukuh kemauan serta memperhalus perasaan - Tan Malaka',
    'Kegagalan hanya terjadi bila kita menyerah - BJ Habibie',
    'Di depan memberi teladan, di tengah memberi bimbingan, di belakang memberi dorongan - Ki Hajar Dewantara',
    'Belajarlah seperti orang kelaparan. Ia tak akan mudah puas',
    'Kesuksesan dimulai dari langkah pertama',
    'Jangan berhenti ketika lelah, berhentilah ketika selesai',
    'Percayalah pada proses',
    'Ilmu adalah harta yang tidak akan pernah habis',
    'Berani belajar berarti berani sukses',
    'Setiap hari adalah kesempatan untuk belajar hal baru',
    'Belajar bukan tentang menjadi yang terbaik, tapi menjadi lebih baik',
    'Pengetahuan tanpa tindakan adalah pemborosan - Al-Ghazali',
    'Bermimpilah setinggi ujung langit, jika engkau jatuh, engkau akan jatuh di antara bintang-bintang - Soekarno',
    'Keberhasilan bukanlah milik orang yang pintar. Keberhasilan adalah kepunyaan mereka yang senantiasa berusaha - BJ Habibie',
    'Orang yang tidak membaca buku tidak memiliki keunggulan dibandingkan dengan orang yang tidak bisa membacanya - Mark Twain',
    'Belajar dengan hati, hasilkan prestasi',
    'Semangat adalah bahan bakar kesuksesan',
  ];

  @override
  void initState() {
    super.initState();
    _getRandomQuote();
  }

  void _getRandomQuote() {
    final random = DateTime.now().millisecondsSinceEpoch % _motivasiQuotes.length;
    setState(() {
      _currentQuote = _motivasiQuotes[random.toInt()];
    });
  }

  void _openWebView(String title, String url) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => _WebViewPage(title: title, url: url),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgPrimary,
      appBar: AppBar(
        title: const Text('📚 Edukasi', style: TextStyle(color: primaryWhite)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: Container(
            padding: const EdgeInsets.all(8),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [glassPrimary, glassSecondary],
              ),
              borderRadius: BorderRadius.circular(12),
              border: Border.all(color: glassBorder),
            ),
            child: const Icon(Icons.arrow_back_ios_new, color: accentNeon, size: 18),
          ),
          onPressed: () => Navigator.pop(context),
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh, color: accentNeon),
            onPressed: _getRandomQuote,
            tooltip: 'Motivasi baru',
          ),
        ],
      ),
      body: Column(
        children: [
          // ===== KATA MOTIVASI =====
          Container(
            margin: const EdgeInsets.all(16),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [glassPrimary, glassSecondary],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: glassBorder),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Icon(Icons.format_quote, color: accentNeon, size: 20),
                    const SizedBox(width: 8),
                    const Text(
                      'Kata Motivasi',
                      style: TextStyle(
                        color: accentNeon,
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                        letterSpacing: 1,
                      ),
                    ),
                    const Spacer(),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                      decoration: BoxDecoration(
                        gradient: neonGradient,
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: const Text(
                        'HARI INI',
                        style: TextStyle(
                          color: primaryWhite,
                          fontSize: 8,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Text(
                  _currentQuote,
                  style: const TextStyle(
                    color: primaryWhite,
                    fontSize: 14,
                    height: 1.5,
                    fontStyle: FontStyle.italic,
                  ),
                ),
                const SizedBox(height: 8),
                Align(
                  alignment: Alignment.centerRight,
                  child: GestureDetector(
                    onTap: _getRandomQuote,
                    child: Container(
                      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                      decoration: BoxDecoration(
                        color: accentNeon.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(12),
                        border: Border.all(color: accentNeon.withOpacity(0.2)),
                      ),
                      child: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(Icons.refresh_rounded, color: accentNeon, size: 14),
                          const SizedBox(width: 4),
                          Text(
                            'Ganti',
                            style: TextStyle(color: accentNeon, fontSize: 10),
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ),

          // ===== KATEGORI =====
          Container(
            height: 50,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _categories.length,
              itemBuilder: (context, index) {
                final cat = _categories[index];
                final isSelected = _selectedCategory == index;
                return Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 4),
                  child: FilterChip(
                    label: Text(cat['name']),
                    selected: isSelected,
                    onSelected: (selected) {
                      if (selected) {
                        setState(() => _selectedCategory = index);
                      }
                    },
                    backgroundColor: glassSecondary,
                    selectedColor: accentNeon.withOpacity(0.15),
                    labelStyle: TextStyle(
                      color: isSelected ? accentNeon : softGrey,
                      fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                      fontSize: 12,
                    ),
                    side: BorderSide(
                      color: isSelected ? accentNeon : glassBorder,
                      width: isSelected ? 1.5 : 1,
                    ),
                    shape: RoundedRectangleBorder(
                      borderRadius: BorderRadius.circular(20),
                    ),
                  ),
                );
              },
            ),
          ),

          // ===== LIST WEBSITE =====
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: ListView.builder(
                itemCount: _categories[_selectedCategory]['items'].length,
                itemBuilder: (context, index) {
                  final item = _categories[_selectedCategory]['items'][index];
                  return _buildWebsiteCard(item);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWebsiteCard(Map<String, dynamic> item) {
    return TweenAnimationBuilder(
      duration: const Duration(milliseconds: 300),
      tween: Tween<double>(begin: 0, end: 1),
      builder: (context, double value, child) {
        return Opacity(
          opacity: value,
          child: Transform.translate(
            offset: Offset(0, 20 * (1 - value)),
            child: child,
          ),
        );
      },
      child: GestureDetector(
        onTap: () => _openWebView(item['name'], item['url']),
        child: Container(
          margin: const EdgeInsets.only(bottom: 12),
          padding: const EdgeInsets.all(16),
          decoration: BoxDecoration(
            gradient: LinearGradient(
              colors: [glassPrimary, glassSecondary],
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
            ),
            borderRadius: BorderRadius.circular(16),
            border: Border.all(color: glassBorder),
          ),
          child: Row(
            children: [
              Container(
                padding: const EdgeInsets.all(10),
                decoration: BoxDecoration(
                  gradient: neonGradient,
                  borderRadius: BorderRadius.circular(12),
                  boxShadow: [
                    BoxShadow(
                      color: accentNeon.withOpacity(0.2),
                      blurRadius: 8,
                    ),
                  ],
                ),
                child: Icon(
                  Icons.open_in_browser_rounded,
                  color: primaryWhite,
                  size: 20,
                ),
              ),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      item['name'],
                      style: const TextStyle(
                        color: primaryWhite,
                        fontWeight: FontWeight.bold,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'Klik untuk belajar',
                      style: TextStyle(
                        color: softGrey,
                        fontSize: 11,
                      ),
                    ),
                  ],
                ),
              ),
              Container(
                padding: const EdgeInsets.all(8),
                decoration: BoxDecoration(
                  color: accentNeon.withOpacity(0.1),
                  borderRadius: BorderRadius.circular(8),
                  border: Border.all(color: accentNeon.withOpacity(0.2)),
                ),
                child: Icon(
                  Icons.arrow_forward_ios_rounded,
                  color: accentNeon,
                  size: 14,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ===== WEBVIEW =====
class _WebViewPage extends StatefulWidget {
  final String title;
  final String url;
  const _WebViewPage({required this.title, required this.url});

  @override
  State<_WebViewPage> createState() => __WebViewPageState();
}

class __WebViewPageState extends State<_WebViewPage> {
  late WebViewController _controller;
  bool _isLoading = true;

  // === TEMA NEON (TAMBAHKAN DI SINI) ===
  static const Color bgPrimary = Color(0xFF0A0E1A);
  static const Color accentNeon = Color(0xFF00F0FF);
  static const Color primaryWhite = Color(0xFFFFFFFF);

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..setBackgroundColor(Colors.black)
      ..setNavigationDelegate(
        NavigationDelegate(
          onPageStarted: (_) => setState(() => _isLoading = true),
          onPageFinished: (_) => setState(() => _isLoading = false),
        ),
      )
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: bgPrimary,
      appBar: AppBar(
        title: Text(widget.title, style: const TextStyle(color: primaryWhite)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back, color: primaryWhite),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Stack(
        children: [
          WebViewWidget(controller: _controller),
          if (_isLoading)
            Container(
              color: bgPrimary.withOpacity(0.7),
              child: const Center(
                child: CircularProgressIndicator(color: accentNeon, strokeWidth: 3),
              ),
            ),
        ],
      ),
    );
  }
}